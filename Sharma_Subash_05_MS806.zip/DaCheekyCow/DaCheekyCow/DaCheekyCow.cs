﻿/*
**************************************************************
| Student Name: Subash Sharma                                |
| Student ID: 18231592                                       |
| Date: 14/11/2018                                           |
| Assignment 05: An EPOS                                     |                                       
**************************************************************
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DaCheekyCow
{
    public partial class DaCheekyCow : Form
    {
        const int ROWS = 5, COLUMNS = 12, TRANSACTIONLENGTH = 6;
        int CURSTOCK,SELECTEDROW,SELECTEDCOLUMN,QUANTITY, TOTALQUANTITY=0;
        decimal TOTALPRICE=0,SELECTEDPRICE;
        string SELECTEDROWITEM, SELECTEDCOLUMNITEM;
        string STOCKFILEPATH="dccstock.csv";
        string PRICEFILEPATH = "dccprices.csv";
        string TEMPFILEPATH = "dccstocktemp.csv";
        List<string> TRANSACTIONLOG = new List<string>();
        List<string> MENUSIZEANDPRICELIST = new List<string>();
        decimal[,] Prices = new decimal[ROWS, COLUMNS];
        int[,] Stock = new int[ROWS, COLUMNS];
        bool ISTRANSACTIONDONE = false;

        private void WriteStock()
        {
            StreamReader StockFile = new StreamReader(@STOCKFILEPATH);
            int row = 0;
            string Line;
            while ((Line = StockFile.ReadLine()) != null)
            {
                string[] LineVal = Line.Split(',');
                if (row == 0)
                {
                    TextWriter WriteColumn = new StreamWriter(@TEMPFILEPATH, true);
                    WriteColumn.WriteLine(Line);
                    WriteColumn.Close();
                }
                else
                {
                    string InsertLine= string.Empty;
                    TextWriter tw = new StreamWriter(TEMPFILEPATH, true);
                    InsertLine += LineVal[0];
                    for (int StockIndex =0; StockIndex < LineVal.Length - 1; StockIndex++)
                    {
                        InsertLine += ",";
                        InsertLine += Stock[row - 1, StockIndex];
                    }
                    tw.WriteLine(InsertLine);
                    tw.Close();
                }                    
                row++;
            }
            StockFile.Close();
            File.Delete(@STOCKFILEPATH);
            File.Move(TEMPFILEPATH, STOCKFILEPATH);

        }


        private string GenerateTransactionNumber(int TransactionLength)
        {
            Random Rand = new Random();
            string TrxNumber= string.Empty;
            for (int index = 0; index < 2; index++)
            {
                TrxNumber += Rand.Next(0, 9).ToString();
            }
            for (int index = 0; index < TransactionLength;index++)
            {
                TrxNumber += ((char)Rand.Next(97, 122)).ToString(); 
            }

            return TrxNumber;
        }



        private void FillStock()
        {
            if (File.Exists(@STOCKFILEPATH))
            {
                StreamReader StockFile = new StreamReader(@STOCKFILEPATH);
                string Line = StockFile.ReadLine();
                int row = 0;
                while ((Line = StockFile.ReadLine()) != null)
                {
                    string[] LineVal = Line.Split(',');
                    int StockIndex;

                    for (StockIndex = 0; StockIndex < LineVal.Length - 1; StockIndex++)
                    {
                        Stock[row, StockIndex] = int.Parse(LineVal[StockIndex + 1]);

                    }
                    row++;
                }
                StockFile.Close();
            }
            else
            {
                MessageBox.Show("Stock File Not Found","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                this.Close();
            }
            
        }
 

        private void FillPrices()
        {
            if (File.Exists(PRICEFILEPATH) )
                {
                StreamReader PriceFile = new StreamReader(PRICEFILEPATH);
                string Line = PriceFile.ReadLine();
                int row = 0;
                while ((Line = PriceFile.ReadLine()) != null)
                {
                    string[] LineVal = Line.Split(',');
                    int PriceIndex;

                    for (PriceIndex = 0; PriceIndex < LineVal.Length - 1; PriceIndex++)
                    {
                        Prices[row, PriceIndex] = decimal.Parse(LineVal[PriceIndex + 1]);

                    }
                    row++;
                }
                PriceFile.Close();
            }
            else
            {
                MessageBox.Show("Price File Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }


        

        public DaCheekyCow()
        {
            InitializeComponent();
        }

        private void SummaryButton_Click(object sender, EventArgs e)
        {
            
            if (File.Exists(STOCKFILEPATH))
            {
                
                DataTable StockData = new DataTable();
                StreamReader StockFile = new StreamReader(STOCKFILEPATH);
                string Line;
                int row = 0;
                while ((Line=StockFile.ReadLine()) !=null)
                {
                   
                    string[] LineVal = Line.Split(',');
                    if (row == 0)
                    {
                        
                        for (int StockIndex = 0; StockIndex < LineVal.Length - 1; StockIndex++)
                        {
                            StockData.Columns.Add(LineVal[StockIndex],typeof(string));
                        }
                             
                    }
                    else
                    {
                        for (int i=0; i< ROWS; i++)
                        {
                            if (i==0)
                            StockData.Rows.Add(LineVal[i]);
                        }
                    }

                    row++;
                }
                int RowLimit = 0, ColumnLimit = 0;
                while (RowLimit < ROWS)
                {
  
                    for (ColumnLimit = 0; ColumnLimit < COLUMNS-1; ColumnLimit++)
                    {
                        StockData.Rows[RowLimit][ColumnLimit+1] = Stock[RowLimit, ColumnLimit].ToString();
                    }
                        //MessageBox.Show(StockData.Rows[RowLimit+1][ColumnLimit+1].ToString());
                    RowLimit++;

                }
                StockFile.Close();
                StockDataGridView.DataSource = StockData;
                
            }
            else
            {
                MessageBox.Show("Stock File Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show("Stock File Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show("Stock File Not Found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
                  
        }

        private void MenuList_SelectedIndexChanged(object sender, EventArgs e)
        {
            QuantityText.Text = "";
        }

        private void DaCheekyCow_Load(object sender, EventArgs e)
        {
            FillPrices();
            FillStock();
            QuantityLabel.Visible = false;
            QuantityText.Visible = false;
            AddToOrderButton.Visible = false;
            CompleteButton.Visible = false;
            MenuList.Focus();
            SizeList.Focus();
            DisplayButton.Focus();
        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {
            if (MenuList.SelectedIndex != -1)
            {
                if (SizeList.SelectedIndex != -1)
                {

                    
                    SELECTEDROW = SizeList.SelectedIndex;
                    SELECTEDCOLUMN = MenuList.SelectedIndex;
                    SELECTEDROWITEM = SizeList.SelectedItem.ToString();
                    SELECTEDCOLUMNITEM = MenuList.SelectedItem.ToString();
                    SELECTEDPRICE = Prices[SELECTEDROW, SELECTEDCOLUMN];
                    MessageBox.Show("The Price of "+ SELECTEDCOLUMNITEM + " for " +SELECTEDROWITEM + " is €" + SELECTEDPRICE.ToString());
                    QuantityLabel.Visible = true;
                    QuantityText.Visible = true;
                    AddToOrderButton.Visible = true;
                    QuantityText.Focus();
                }
                else
                {
                    MessageBox.Show("Please Select a Size", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            else 
            {
                MessageBox.Show("Please Select a Meal","Warning!",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            MenuList.ClearSelected();
            SizeList.ClearSelected();
            QuantityLabel.Visible = false;
            QuantityText.Text = "";
            QuantityText.Visible = false;
            AddToOrderButton.Visible = false;
            CompleteButton.Visible = false;
            QUANTITY = 0;
            SELECTEDPRICE = 0;
            StockDataGridView.DataSource = "";
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            if (TRANSACTIONLOG.Count > 0)
            {
                foreach (string line in TRANSACTIONLOG)
                {
                    WriteTrxFile(line);
                }
                WriteStock();
            }

            this.Close();
        }

        private void CompleteButton_Click(object sender, EventArgs e)
        {
            if (ISTRANSACTIONDONE)
            {
                MessageBox.Show("This Transaction has been Done, Please click on Clear and Choose Another option");
            }
            else
            {
                string TrxNumber;
                TrxNumber = GenerateTransactionNumber(TRANSACTIONLENGTH);
                DialogResult Result = MessageBox.Show("Please Find the Transaction Details Below:\n" +
                                "Transaction Number:" + TrxNumber + "\n"
                               + "Selected Meal,Size, Quantity and Price:" + "\n" + string.Join("\n", MENUSIZEANDPRICELIST) + "\n"
                               + "Total Quantity: " + TOTALQUANTITY + "\n"
                               + "Total Order Cost: " + TOTALPRICE.ToString("€#.##") + "\n"
                               + "Please Click on OK to Book the Order."
                                , "Success", MessageBoxButtons.OKCancel);
                //StreamWriter WriteFile = ;
                if (Result == DialogResult.OK)
                {

                    Stock[SELECTEDROW, SELECTEDCOLUMN] = CURSTOCK - QUANTITY;
                    TRANSACTIONLOG.Add("Transaction Number: " + TrxNumber);
                    TRANSACTIONLOG.Add("Total Quantity of the Order: " + TOTALQUANTITY.ToString());
                    TRANSACTIONLOG.Add("Total Price of the Order: " + TOTALPRICE.ToString());
                    MessageBox.Show("Transaction has been Saved Successfuly. Please click on clear button to take another Booking", "Success", MessageBoxButtons.OK);
                    ClearButton.Focus();
                    MenuList.ClearSelected();
                    SizeList.ClearSelected();
                    QuantityText.Text = "";
                    ISTRANSACTIONDONE = true;
                    MENUSIZEANDPRICELIST.Clear();
                }
                else
                {
                    MessageBox.Show("Click on Clear to Cancel the Order", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            
                              
        }

        private void WriteTrxFile(string element)
        {
            string FilePath = DateTime.Today.ToString("yyyy-MM-dd") + ".txt";
            TextWriter Write = new StreamWriter(@FilePath, true);
            Write.WriteLine(element);
            Write.Close();
        }

        private void AddToOrderButton_Click(object sender, EventArgs e)
        {
            try
            {
                QUANTITY = int.Parse(QuantityText.Text);
                if (QUANTITY > 0)
                {
                    
                    CURSTOCK = Stock[SELECTEDROW, SELECTEDCOLUMN];
                    if (CURSTOCK == 0)
                    {
                        MessageBox.Show("Item out of Stock, Please choose another Menu and Size", "Warning", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        ClearButton.Focus();
                    }

                    else 
                    {
                        if (CURSTOCK < QUANTITY)
                        {
                            MessageBox.Show("We have only " + CURSTOCK.ToString() + " items left in Stock of " + SELECTEDCOLUMNITEM + " in " + SELECTEDROWITEM + " Size " + ", Please Enter Numeric Value less than or equal to Current Stock ", "warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            QuantityText.Text = CURSTOCK.ToString();
                            QuantityText.SelectAll();
                            QuantityText.Focus();
                        }
                        else
                        {


                            TOTALQUANTITY += QUANTITY;
                            TOTALPRICE += QUANTITY * SELECTEDPRICE;
                            MENUSIZEANDPRICELIST.Add("Meal Type: "+SELECTEDCOLUMNITEM);
                            MENUSIZEANDPRICELIST.Add("Meal Size: " + SELECTEDROWITEM);
                            MENUSIZEANDPRICELIST.Add("Meal Quantity:"+ QUANTITY.ToString());
                            MENUSIZEANDPRICELIST.Add("Meal Price:" + SELECTEDPRICE.ToString("€#.##"));
                            int iterator = 1;
                            int MENULINE = 4;
                            foreach (string elem in MENUSIZEANDPRICELIST)
                            {
                                int CHKMODULO = iterator % MENULINE;
                                switch (CHKMODULO)
                                {
                                    case 1:
                                        TRANSACTIONLOG.Add(elem);
                                        break;
                                    case 2:
                                        TRANSACTIONLOG.Add(elem);
                                        break;
                                    case 3:
                                        TRANSACTIONLOG.Add(elem);
                                        break;
                                    case 0:
                                        TRANSACTIONLOG.Add(elem);
                                        break;
                                }
                                
                                iterator++;

                            }
                            MessageBox.Show("Item remaining in stock is " + (CURSTOCK - QUANTITY).ToString(), "Notification", MessageBoxButtons.OK);
                            CompleteButton.Visible = true;
                            CompleteButton.Focus();
                            ISTRANSACTIONDONE = false;
                            

                        };

                    };

                    
                }
                else 
                {
                    MessageBox.Show("Please Enter a value greater than 0", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            catch (FormatException) 
            {
                MessageBox.Show("Please Enter Numerical Value","Warning!",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }
    }
}
