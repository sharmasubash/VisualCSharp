﻿/*
**************************************************************
| Student Name: Subash Sharma                                |
| Student ID: 18231592                                       |
| Date: 14/11/2018                                           |
| Assignment 04: An Application which enable employees of    |
|  MyInvestment Bank Corp. to process Investments of their   |
| clients                                                    |
**************************************************************
 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

// The Directory or Namespace where the source code will get stored


namespace InvestQ
{
    public partial class InvestQ : Form
    {
        /* Global Constants to hold values of Interest 
         * Rates to various terms.
         */
        const decimal INTERESTRATEONEMONTHUPTO100K = 0.50000M;
        const decimal INTERESTRATETHREEMONTHUPTO100K = 0.62500M;
        const decimal INTERESTRATESIXMONTHUPTO100K = 0.71200M;
        const decimal INTERESTRATETWELVEMONTHUPTO100K = 1.12500M;

        const decimal INTERESTRATEONEMONTHABOVE100K = 0.60000M;
        const decimal INTERESTRATETHREEMONTHABOVE100K = 0.72500M;
        const decimal INTERESTRATESIXMONTHABOVE100K = 0.81200M;
        const decimal INTERESTRATETWELVEMONTHABOVE100K = 1.15000M;

        /* Global Constants to hold Values of Transaction related information
         * such as length of transaction, Values stored for each transaction
         * and the modular position where transaction will be stored.
         */
/* 8 Values such as term, Name, Email, Balance etc. get stored in file for each
* transaction
*/
        const int VALUESSTOREDFORONETRX = 8;
        const int TRANSACTIONNOPOSITION = 1;
        const int TRANSACTIONLENGTH = 6;

        // Global constant to store Bonus Value
        const decimal BONUS = 5000.00M;

        // A string constant to put a place holder to access and create a file

        const string FILELOCATION = "C:\\Users\\subash\\Desktop" +
            "\\InvestQ\\Transaction.txt";

        // Global Variables to store Principal in decimal
        decimal Principal;

        /* variables to store values of Balance, Term and Interest Rate in 
         * string format. As these variables should be defined as decimals,
         * I have taken them as a string because a lot of times these are 
         * getting retrieved from the list box. 
         */

        string Balance;
        string Term;
        string InterestRate;

        // An Empty Constructor to initialse a class

        public InvestQ()
        {
            InitializeComponent();
        }

        // On Click Display Function
        private void DisplayButtonBox_Click(object sender, EventArgs e)
        {
// Clear any Items if stored in Balance List Box
            BalanceListBox.Items.Clear();
// Disable "Confirm" Button
            ConfirmButtonBox.Visible = false;
            try
            {
// fetch the entered Investment by Employee and type cast it to decimal

                Principal = decimal.Parse(InputPrincipalTextBox.Text);

// If Entered Principal Investment is greater than zero, 
                if (Principal >= 0.00M)
                {
/* If Entered Principal Investment is greater than 1 million, Display a 
 * pop up to make them aware about bonus.
 */

                    if (Principal > 1000000.00M)
                    {
                        MessageBox.Show("Investments of more than 1 Million " +
                                        "for 6 Months or more receive " +
                            "an additional 5000 euros bonus on term completion");

                    }
/* Investment Details containing group box gets enabled
 * once clicked on Display Button
 */
                    InvestGroupBox.Visible = true;

// Calculate the Balance Amount using CalcBalance Method

                    CalcBalance(Principal);

// Disable "Proceed" and "Investor Details Group Box"

                    InvestorDetailGroupBox.Visible = false;
                    ProceedButtonBox.Enabled = false;
                }
                else
                {
/* If Entered Principal Amount is less than zero, Display a message to Employee
 * to enter a non-negative value
 */
                    MessageBox.Show("Please Enter Non-negative Values",
                                    "Warning", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    // Focus on Principal Text Box
                    InputPrincipalTextBox.Focus();
                    InputPrincipalTextBox.SelectAll();
                }

            }
            catch (FormatException)
            {
/* If Entered Principal Amount is not in Numeric Form, raise a Format Exception
 * with a message box to enter prinicipal in numeric format
 */
                MessageBox.Show("Please Enter Principal Value in Numeric Form",
                                "Error", MessageBoxButtons.OK, 
                                MessageBoxIcon.Error);
                // Focus should again be on Principal Text Box
                InputPrincipalTextBox.Focus();
                InputPrincipalTextBox.SelectAll();
            }
        }
// On Load Form Function

        private void InvestQ_Load(object sender, EventArgs e)
        {

/* Only Search, Summary, Exit, Clear and Display button along with their labels
 * and text boxes will remain visible, Rest other boxes will be hidden when 
 * application loads
 */
            InvestGroupBox.Visible = false;
            SummaryGroupBox.Visible = false;
            ProceedButtonBox.Enabled = false;
            EnterTrxNumberTextBox.Visible = false;
            EnterTransactionDetailBox.Visible = false;
            SearchButtonBox.Visible = false;
            ConfirmButtonBox.Visible = false;
        }

// On change Balance List Box Index 

        private void BalanceListBox_SelectedIndexChanged(object sender,
                                                         EventArgs e)
        {
/* If Employee select a term displayed in Balance List box, Proceed Button 
 *  gets enabled, else remains disabled
 */
            if (BalanceListBox.SelectedIndex != -1)
            { 
                ProceedButtonBox.Enabled = true; 
            }
            else
            { 
                ProceedButtonBox.Enabled = false;
            }
                
        }
// On click Proceed Button

        private void ProceedButtonBox_Click(object sender, EventArgs e)
        {
/* Proceed Button, Unhides the Investor Details Group box and Confirm Button.
 * This button also enables the Confirm Button
 */

            InvestorDetailGroupBox.Visible = true;
            ConfirmButtonBox.Visible = true;
            ConfirmButtonBox.Enabled = true;
        }
// On Click Confirm Button

        private void ConfirmButtonBox_Click(object sender, EventArgs e)
        {
            if (TransactionValueTextBox.Text.Length == TRANSACTIONLENGTH)
// If Transaction Number length is equal to 6
            {
                if (CustomerNameValueTextBox.Text.Length != 0)
// and If Employee has entered the Name of Customer
                {
                    if (TelephoneNumberValueTextBox.Text.Length != 0)
// and If Employee has entered the Telephone Number
                    {
                        if (EmailAddressValueTextBox.Text.Length != 0)
// and If Employee has entered the Email Address
                        {
                            if (CheckUniqueTransaction())
// and IF the transaction exists
                            {
/* Display a message to employee, conveying the message to enter a new 
 * Transaction Number of 6 Characters
 */
                                MessageBox.Show("Transaction Number Exists," +
                                                " Please Enter a new " +
                                                "Transaction Number of " +
                                                "6 Characters.", "Warning", 
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Warning);

/* Focus shoule be on the text box where employee has entered the 
 * transaction
 */
                                TransactionValueTextBox.Focus();
                                TransactionValueTextBox.SelectAll();
                            }
                            else
                            {
// if transaction number is Unique
// Define a local Variable to store the Investment Information

                                string BalanceLine;

/* Store the selected term from the Balance List Box in the above defined 
 * variable
 */

                                BalanceLine = BalanceListBox.SelectedItem.
                                                            ToString();
/* As each item in the balance list box contains information related to 
 * a particular type on investment plan separated by a "pipe" operator
 * . Extensive use of Index of and Substring will be seen in few lines 
 * below
 */

/* Get the term by picking the start index and the end index.
 * End should be the Space which separate the integer of term from 
 * "Month" String. Example: "1 Month|0.1232|€434232" shall return 1.
 */
                                Term = BalanceLine.
                                Substring(0, BalanceLine.IndexOf(' '));

/* Store the value of Balance Information by removing the data before the first
 * pipe operator. Example: "1 Month|0.1232|€434232" shall be "0.1232|€434232"
 */
                                BalanceLine = BalanceLine.
                                         Substring(BalanceLine.IndexOf('|') + 1, 
                                          BalanceLine.Length - 
                                          BalanceLine.IndexOf('|') - 1);
/* Get Interest Rate, the begin index will be the first character position and
 * end index would be the position of pipe character
 */

                                InterestRate = BalanceLine.
                                Substring(0, BalanceLine.IndexOf('|'));
/* Afer retrieving value of Interest Rate, store the value of Balance from the 
 * first pipe to the last pipe. For Example : "0.1231|€434232" would
 * become "€434232" 
 */

                                BalanceLine = BalanceLine.
                                Substring(BalanceLine.IndexOf('|') + 1, 
                                          BalanceLine.Length -
                                          BalanceLine.IndexOf('|') - 1);
// take the substring starting from one and till the end of the string 

                                Balance = BalanceLine.
                                Substring(1, BalanceLine.Length - 1);

/* Store these values in a dialog to display when employee presses the
 * confirm button
 */

                                DialogResult Result =
                                    MessageBox.Show("Your Transaction " 
                                    +"Details:\n"
                                    + "Transaction Number: " 
                                    + TransactionValueTextBox.Text + "\n"
                                    + "Customer Name: " 
                                    + CustomerNameValueTextBox.Text + "\n"
                                    + "Telephone Number: " 
                                    + TelephoneNumberValueTextBox.Text + "\n"
                                    + "Email Address: " 
                                    + EmailAddressValueTextBox.Text + "\n"
                                    + "Investment Details: \n"
                                    + "Term: " + Term + "\n"
                                    + "Interest Rate: " + InterestRate + "\n"
                                    + "Balance: " + Balance + "\n"
                                    + "Would you like to Proceed ?"
                                    , "Notification", 
                                                    MessageBoxButtons.OKCancel,
                                                    MessageBoxIcon.Information);
/* If Employee processes the transaction by clicking on "OK"
 */
                                if (Result == DialogResult.OK)
                                {
// Write Transaction Number in file 
                                    WriteInFile(FILELOCATION, 
                                                TransactionValueTextBox.Text);
// Write Customer Name in File
                                    WriteInFile(FILELOCATION, 
                                                CustomerNameValueTextBox.Text);
// Write Telephone Number in File
                                    WriteInFile(FILELOCATION, 
                                                TelephoneNumberValueTextBox.Text);
// Write Email Address in File
                                    WriteInFile(FILELOCATION, 
                                                EmailAddressValueTextBox.Text);
// Write Term in File
                                    WriteInFile(FILELOCATION, 
                                                Term);
// Write Interest Rate in File
                                    WriteInFile(FILELOCATION, 
                                                InterestRate);
// Write Balance Amount in File
                                    WriteInFile(FILELOCATION, 
                                                Balance);
// Write Principal Amount in File
                                    WriteInFile(FILELOCATION, 
                                                InputPrincipalTextBox.Text);
/* Click on Ok, Shows another message to employee regarding the data persistance
 */
                                    DialogResult res =
                                    MessageBox.Show("Your Transaction" +
                                                    " has been saved" +
                                                    " Successfully!", "Success", 
                                        MessageBoxButtons.OK,
                                                    MessageBoxIcon.Information);
// IF click on "OK"
                                    if (res == DialogResult.OK)
                                    {

/* Clear the transaction details such as Name, email address, 
 * transaction number, Term Selection etc. Disable button like 
 * Confirm 
 */

                                        TransactionValueTextBox.Clear();
                                        CustomerNameValueTextBox.Clear();
                                        TelephoneNumberValueTextBox.Clear();
                                        EmailAddressValueTextBox.Clear();
                                        ConfirmButtonBox.Visible = false;
                                        InvestorDetailGroupBox.Visible = false;
                                        BalanceListBox.ClearSelected();
                                        
                                        Balance = "";
                                        InterestRate = "";
                                        Term = "";

                                    }

                                }
                            }
                        }
                        else
                        {

/* If employee doesnt enter the email address, pop up a message to enter 
 * customer email address
 */
                            MessageBox.Show("Please Enter Customer" +
                                            " Email Address", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
// Focus should be on Email address text box
                            EmailAddressValueTextBox.Focus();
                            EmailAddressValueTextBox.SelectAll();
                        }
                    }
                    else
                    {
/* if employee forgets to enter the telephone number, pop up a message to enter
 * customer telephone number
 */
                        MessageBox.Show("Please Enter Customer" +
                                        " Telephone Number", "Warning",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
// Focus should be on Telephone Number Text Box

                        TelephoneNumberValueTextBox.Focus();
                        TelephoneNumberValueTextBox.SelectAll();
                    }

                }
                else
                {
/* If employee forgets to enter the customer name, pop up a message to 
 * enter customer name
 */
                    MessageBox.Show("Please Enter Customer Name",
                                    "Warning", MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);

// Focus should on Customer Name Text Box

                    CustomerNameValueTextBox.Focus();
                    CustomerNameValueTextBox.SelectAll();
                }
            }
            else
            {
/* If employee enters a transaction number having length less than or greater
 * than 6, pop up a message to remind him to enter 6 character unique trx
 * number
 */
                MessageBox.Show("Please Enter Unique " +
                                "6 Character Transaction Number",
                    "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
// Focus should be on Transaction Number Text Box
                TransactionValueTextBox.Focus();
                TransactionValueTextBox.SelectAll();
            }
        }

// On Click Trx Radio Button Function
        private void TrxRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (TrxRadioButton.Checked)
// If Transaction search Radio Button is pressed
            {
// Rename the label of EnterTrxNumberTextBox
                EnterTrxNumberTextBox.Text = "Enter Transaction Number";
// Unhide the text label
                EnterTrxNumberTextBox.Visible = true;
// Unhide the transaction number input text box
                EnterTransactionDetailBox.Visible = true;
// Enable Search button
                SearchButtonBox.Visible = true;
// Clear list of Transactions
                EnterTransactionDetailBox.Clear();
            }
            else
            {
/* if not checked, unhide all the label, text and button boxes related to 
 * search
 */
                EnterTrxNumberTextBox.Visible = false;
                EnterTransactionDetailBox.Visible = false;
                SearchButtonBox.Visible = false;
            }
        }
// On Click function for email radio button

        private void EmailRadioButtonBox_CheckedChanged(object sender, EventArgs e)
        {
            if (EmailRadioButtonBox.Checked)
            {
/* if email radio button is checked, Change the search label name from
 * "Enter Transaction Number" to "Enter Email ID" and unhide label and 
 * text box and clear the text box
 */
                EnterTrxNumberTextBox.Text = "Enter Email ID";
                EnterTrxNumberTextBox.Visible = true;
                EnterTransactionDetailBox.Visible = true;
                SearchButtonBox.Visible = true;
                EnterTransactionDetailBox.Clear();
            }
            else
            {
/* IF Email Radio Button is not checked, Let all the labels, text boxes and 
 * button boxes be hidden
 */

                EnterTrxNumberTextBox.Visible = false;
                EnterTransactionDetailBox.Visible = false;
                SearchButtonBox.Visible = false;
            }

        }
// On Click Search Button

        private void SearchButtonBox_Click(object sender, EventArgs e)
        {
// Clear all the label boxes which shows the result comes out of search button

            SummaryTrxValueBox.Text = "";
            SummaryCustNameValueBox.Text = "";
            SummaryTelNumValueBox.Text = "";
            SummaryEmailAddValueBox.Text = "";
            SummaryTermValueBox.Text = "";
            SummaryInterestRateValueBox.Text = "";
            SummaryBalanceValueBox.Text = "";

            try
            {

// Get the transaction Number and store in a local variable TrxNumber
            string TrxNumber = EnterTransactionDetailBox.Text;
                if (TrxNumber == "" && TrxRadioButton.Checked)
                {
/* If the radio button of Transaction is checked and Transaction number has not
 * been entered in the text box, a message pops up to enter the 
 * transaction number
 */

                    MessageBox.Show("Please Enter a Transaction Number",
                                    "Warning", 
                                    MessageBoxButtons.OK, 
                                    MessageBoxIcon.Warning);
                }
                else if ((TrxNumber == "" && EmailRadioButtonBox.Checked))
                {
/* If the radio button of By Email is checked and Transaction number has not
 * been entered in the text box, a message pops up to enter the 
 * transaction number
 */
                    MessageBox.Show("Please Enter an Email ID",
                                    "Warning",
                                    MessageBoxButtons.OK, 
                                    MessageBoxIcon.Warning);
                }
                else {
// IF User enters the transaction number

                    if (TrxRadioButton.Checked)
                    {
// if Transaction Radio Button is checked
                        if (!GetTransaction(TrxNumber))
                        {
/* If transaction not found by function "GetTransaction" it returns "False" 
 * which pops up a message to display "Transaction  not  found"
 */

                            MessageBox.Show("Transaction Not Found",
                                            "Warning",MessageBoxButtons.OK,
                                            MessageBoxIcon.Warning);
                        }
                    }

                    if (EmailRadioButtonBox.Checked)
                    {
// if Email Radio Button is checked
                        if (!GetTrxByEmail(TrxNumber))
                        {
/* If email hasn't found by function "GetTransaction" it returns "False" 
 * which pops up a message to display "Email Address  not  found"
 */

                            MessageBox.Show("Email Address Not Found",
                                            "Warning", 
                                            MessageBoxButtons.OK, 
                                            MessageBoxIcon.Warning);
                        }
                    }
                }
            
        }
        catch (Exception ex) {

// Catch exception and display message

                MessageBox.Show(ex.Message);
            }
        }


 // If the Transaction List box selection changes   

        private void TransactionListBox_SelectedIndexChanged(object sender,
                                                             EventArgs e)
        {
            if (TransactionListBox.SelectedIndex != -1)
            {
/* if user has selected a Transaction from the Transaction List box, store 
 * transaction value in local variable TrxNumber
 */

                string TrxNumber = TransactionListBox.SelectedItem.ToString();
/* A Function which retrieves the details of a transaction 
 * and display that information in various labels
 */
                TrxSummaryByTrxNumber(TrxNumber);
            }
        }

// On Click Exit function

        private void ExitButtonBox_Click(object sender, EventArgs e)
        {
// Close the application
            this.Close();
        }

// On Click Summary Function

        private void SummaryButtonBox_Click(object sender, EventArgs e)
        {
// Clear all the items if exists in transaction list box

            TransactionListBox.Items.Clear();

// Hide the group boxes enabled by Display Button

            InvestGroupBox.Visible = false;

/* "Summary" is a function which returns a boolean value, true indicates 
 * file exists and data processed
 * false indicates file doesn't exist which stops data processing
 */

            if (Summary())
            {
/*
 * to display the summary, we will use the transaction summary group box,
 * few labels will be renamed and cleared to display the summary result
 */
                
  
                SummaryGroupBox.Visible = true;

// Labels to display term gets hidden and emptied

                SummaryTermLabelBox.Visible = false;
                SummaryTermValueBox.Visible = false;
                SummaryTermValueBox.Text = "";

// Labels to display Balance Amount gets hidden and emptied

                SummaryBalanceLabelBox.Visible = false;
                SummaryBalanceValueBox.Visible = false;
                SummaryBalanceValueBox.Text = "";

// Labels to display Interest Rate gets hidden and emptied

                SummaryInterestRateLabelBox.Visible = false;
                SummaryInterestRateValueBox.Visible = false;
                SummaryInterestRateValueBox.Text = "";

/* Few of the labels gets renamed to convey proper information to the User
 * For Example, Transaction Number label box gets renamed from "Transaction 
 * Number" to "Total # of Transactions"
 */

                SummaryTrxNumberLabelBox.Text = "Total # of Transactions";
                SummaryCustNumLabelBox.Text = "Total Amount Invested";
                SummaryTelNumLabelBox.Text = "Total interest accruing" +
                    " on the investments";
                SummaryEmailLabelBox.Text = "Average Duration of" +
                    " the Investment";
                
            }


        }

/* On Click Clear Button, 
 */
        private void ClearButtonBox_Click(object sender, EventArgs e)
        {
            InputPrincipalTextBox.Clear();
            CustomerNameValueTextBox.Clear();
            TransactionValueTextBox.Clear();
            TelephoneNumberValueTextBox.Clear();
            EmailAddressValueTextBox.Clear();
            BalanceListBox.Items.Clear();
            EnterTransactionDetailBox.Clear();
            TransactionListBox.Items.Clear();
            SummaryBalanceValueBox.Text = "";
            SummaryTrxValueBox.Text = "";
            SummaryTermValueBox.Text = "";
            SummaryTelNumValueBox.Text = "";
            SummaryInterestRateValueBox.Text = "";
            SummaryBalanceValueBox.Text = "";
            SummaryEmailAddValueBox.Text = "";
            SummaryCustNameValueBox.Text = "";
            //BalanceDetailsGroupBox.Visible = false;
            InvestGroupBox.Visible = false;
            SummaryTrxNumberLabelBox.Text = "Transaction Number";
            SummaryCustNumLabelBox.Text = "Customer Name";
            SummaryTelNumLabelBox.Text = "Telephone Number";
            SummaryEmailLabelBox.Text = "Email Address";
            SummaryGroupBox.Visible = false;
            EnterTrxNumberTextBox.Text = "Enter Transaction Number";
            EnterTrxNumberTextBox.Visible = false;
            EnterTransactionDetailBox.Clear();
            EnterTransactionDetailBox.Visible = false;
            SearchButtonBox.Visible = false;
            TrxRadioButton.Checked = false;
            EmailRadioButtonBox.Checked = false;

        }
/* A Private method which returns a boolean value of True, if transaction exists
 * in the file, else false even if the file doesn't exists
 */
        private bool Summary()
        {
// A Boolean Flag set to False

            bool FileExistsFlag = false;

            if (File.Exists(FILELOCATION))
            {
// if file exists, set Boolean value to true

                FileExistsFlag = true;

// Create a local variable to store the line Values

                string Line;

// Open file using StreamReader and store it in file ADT

                StreamReader file = new StreamReader(FILELOCATION);

// Initialize a variable to keep track of the number of lines

                int LineNumber = 1;

/* Declare local variables to store summary of total transactions and 
 * initialize all with zero
 */

                int TotalTransactions = 0;
                decimal TotalPrincipalAmount = 0;
                int TotalTerms = 0;
                decimal TotalBalance = 0.00M;

                while ((Line = file.ReadLine()) != null)
/* Loop through the file till the end when file.ReasdLine() returns Null
                 */
                {

/* Do Modulo division of each line number by 8 to keep the values between
 * 0 to 8
 */
                    int checkIndex = LineNumber % VALUESSTOREDFORONETRX;
                    switch (checkIndex)
                    {
// If checkIndex value is 8, Take the principal Amount of that transaction

                        case 0:
                            decimal InvestedAmount = decimal.
                            Parse(Line.ToString());

// add the retrieved value of Invested Amount to the total Principal Amount

                            TotalPrincipalAmount = TotalPrincipalAmount
                                + InvestedAmount;
                            break;
                        case 1:

/* If check Index is 1, Add the line value to the Transaction list box and 
 * add +1 to the total number of transactions
 */
                            TotalTransactions++;
                            TransactionListBox.Items.Add(Line);
                            break;
                        case 5:
/* If check Index is equal to 5, get the term value from the line and store the
 * value in Investmemnt term variable
 * Add up the retrieved value of Invested Term to the total term variable
 */
                            int InvestmentTerm = int.Parse(Line.ToString());
                            TotalTerms = TotalTerms + InvestmentTerm;
                            break;
                        case 7:
/* if check index value is 7, get the seventh line value and store in Bal vari
 * -able, parse value and add it to the Total Balance variable
 */
                            decimal Bal = decimal.Parse(Line.ToString());
                            TotalBalance = TotalBalance + Bal;
                            break;
                    }
// Increase LineNumber by 1
                    LineNumber++;
                }
/* Once all these values has been calculated, Fill these values in the
 * allocated Transaction summary labels
 */
                SummaryTrxValueBox.Text = TotalTransactions.ToString();
                SummaryCustNameValueBox.Text = 
                    TotalPrincipalAmount.ToString("€#.##");
                SummaryTelNumValueBox.Text = 
                    (TotalBalance - TotalPrincipalAmount).ToString("€#.##");
                if (TotalTransactions == 0)
                    SummaryEmailAddValueBox.Text = "0";
                else
                    SummaryEmailAddValueBox.Text = ((double)TotalTerms 
                                                    / TotalTransactions).
                        ToString();
                file.Close();
            }
            else
            {
/* if file doesn't exists, Display the message about no transactions
 */
                MessageBox.Show("No Transactions has been committed Yet," +
                                " Try Later.", 
                                "Notification", MessageBoxButtons.OK, 
                                MessageBoxIcon.Warning);
// Focus gets diverted to Display Button

                DisplayButtonBox.Focus();
                FileExistsFlag = false;

            }
            return FileExistsFlag;
        }
/* A Function to calculate the Balance Amount on the invested money compounded
 * Monthly
 */

        private decimal BalanceAmount(decimal PrincipalAmount, 
                                      decimal RateOfInterest,
                                     int DurationInMonths)
        {
            double Amount;
            double MonthlyRate = (double)RateOfInterest / 100;
            double Rate = MonthlyRate / 12;
            Amount = (double)PrincipalAmount * Math.Pow((1 + Rate),
                                                        DurationInMonths);
            return (decimal)Amount;
        }

/* A method which not only calculates the balance for various terms but
 * also stores their value in balance list box
 */
        private void CalcBalance(decimal PrincipalAmount)
        {
            BalanceListBox.Items.Clear();
            if (PrincipalAmount < 100000.00M)
            {
// If Principal Amount is less than 100k
                int Month;
                for (Month = 1; Month <= 12; Month++)
                {
                    switch (Month)
                    {
                        case 1:
/* if the term is of 1 month, calculate and add value to the
 * Transaction list box
 */
                            BalanceListBox.Items.Add(Month + " Month|" + 
                            INTERESTRATEONEMONTHUPTO100K + "|" +
                            BalanceAmount(PrincipalAmount, 
                                          INTERESTRATEONEMONTHUPTO100K, 
                                          Month).ToString("€#.##"));
                            break;
                        case 3:
/* if the term is of 3 month, calculate and add value to the
 * Transaction list box
 */
                            BalanceListBox.Items.Add(Month + " Months|" + 
                            INTERESTRATETHREEMONTHUPTO100K + "|" + 
                            BalanceAmount(PrincipalAmount, 
                                          INTERESTRATETHREEMONTHUPTO100K, 
                                          Month).ToString("€#.##"));
                            break;
                        case 6:
/* if the term is of 4 month, calculate and add value to the
 * Transaction list box
 */
                            BalanceListBox.Items.Add(Month + " Months|" + 
                            INTERESTRATESIXMONTHUPTO100K + "|" + 
                            BalanceAmount(PrincipalAmount, 
                                          INTERESTRATESIXMONTHUPTO100K,
                                          Month).ToString("€#.##"));
                            break;
                        case 12:
/* if the term is of 1 month, calculate and add value to the
* Transaction list box
*/
                            BalanceListBox.Items.Add(Month + " Months|" + 
                            INTERESTRATETWELVEMONTHUPTO100K + "|" + 
                            BalanceAmount(PrincipalAmount, 
                                          INTERESTRATETWELVEMONTHUPTO100K,
                                          Month).ToString("€#.##"));
                            break;
                    }
                }

            }
            else
            {
// if Principal Amount is greater than 100k

                int Month;
                for (Month = 1; Month <= 12; Month++)
                {
                    switch (Month)
                    {
                        case 1:
/* if the term is of 1 month, calculate and add value to the
* Transaction list box
*/
                            BalanceListBox.Items.Add(Month + " Month|" + 
                            INTERESTRATEONEMONTHABOVE100K + "|" + 
                            BalanceAmount(PrincipalAmount, 
                                          INTERESTRATEONEMONTHABOVE100K, 
                                          Month).ToString("€#.##"));
                            break;
                        case 3:
/* if the term is of 3 month, calculate and add value to the
* Transaction list box
*/
                            BalanceListBox.Items.Add(Month + " Months|" + 
                            INTERESTRATETHREEMONTHABOVE100K + "|" + 
                            BalanceAmount(PrincipalAmount, 
                                          INTERESTRATETHREEMONTHABOVE100K, 
                                          Month).ToString("€#.##"));
                            break;
                        case 6:
                            if (PrincipalAmount > 1000000.00M)
                            {
/* if the term is of 6 month and Principal is greater than 1 million
 * , calculate the balance amount and add Bonus and add value to the
 * Transaction list box
 */
                                BalanceListBox.Items.Add(Month + " Months|" +
                                 INTERESTRATESIXMONTHABOVE100K + "|" + 
                                 (BalanceAmount(PrincipalAmount, 
                                                INTERESTRATESIXMONTHABOVE100K, 
                                                Month) + 
                                  BONUS).ToString("€#.##"));
                            }
                            else
                            {
/* if the term is of 6 month and Principal is less than 1 million
* , calculate the balance amount and add value to the
* Transaction list box
*/
                                BalanceListBox.Items.Add(Month + " Months|" + 
                                INTERESTRATESIXMONTHABOVE100K + "|" +
                                BalanceAmount(PrincipalAmount, 
                                              INTERESTRATESIXMONTHABOVE100K,
                                              Month).ToString("€#.##"));
                            }
                            break;
                        case 12:
                            if (PrincipalAmount > 1000000.00M)
/* if the term is of 12 month and Principal is greater than 1 million
 * , calculate the balance amount and add Bonus and add value to the
 * Transaction list box
 */
                            {
                                BalanceListBox.Items.Add(Month + " Months|" +
                                INTERESTRATETWELVEMONTHABOVE100K + "|" + 
                                 (BalanceAmount(PrincipalAmount, 
                                             INTERESTRATETWELVEMONTHABOVE100K,
                                                Month) + 
                                  BONUS).ToString("€#.##"));
                            }
                            else
/* if the term is of 6 month and Principal is less than 1 million
* , calculate the balance amount and add value to the
* Transaction list box
*/
    
                            {
                                BalanceListBox.Items.Add(Month + " Months|" + 
                                INTERESTRATETWELVEMONTHABOVE100K + "|" + 
                                BalanceAmount(PrincipalAmount, 
                                              INTERESTRATETWELVEMONTHABOVE100K,
                                              Month).ToString("€#.##"));
                            }
                            break;
                    }
                }

            }
        }

/* A function to write data from the Application into a file, If file exists,
 * then WriteInFile appends data in the file, else it creates and appends data
 */
        private void WriteInFile(string FileLocation, string Line)
        {
            string NewFile = FileLocation;
            TextWriter tw = new StreamWriter(NewFile, true);
            tw.WriteLine(Line);
            tw.Close();
        }
/* A function which returns a boolean value of true if transaction is unique
 * else it returns false
 */

        private bool CheckUniqueTransaction()

        {
// Define a boolean variable and assign false value to the variable
            bool TrxExists = false;
// check if file exists
            if (File.Exists(FILELOCATION))
            {
// if file exists, define variable to store file line data and line Number

                string Line;
                int LineReader = 1;
// Create a file object using streamreader for the text file

                StreamReader file = new StreamReader(FILELOCATION);
                while ((Line = file.ReadLine()) != null)
/* Begin from the first line and loop through the file  where Line value 
 * becomes null 
 */
                {
/* Check if the transaction numbered entered is at 1st position or not 
 * check if the length of transaction is equal to 6 or not 
 * and check if the transaction exists or not, if all three condtion 
 * satisfies return true else let it be false
 */
                    TrxExists |=
                        (TransactionValueTextBox.Text == Line 
                         && Line.Length == TRANSACTIONLENGTH && 
                         LineReader % VALUESSTOREDFORONETRX == 
                         TRANSACTIONNOPOSITION);
// Increase LineReader by 1
                    LineReader++;

                }
// Discard Buffered Data of file if it exists;

                file.DiscardBufferedData();
                file.BaseStream.Position = 0;
// Close File
                file.Close();

            }
            return TrxExists;
        }

/* A Boolean Method to retreive transactions and store values of transactions
 * in the transaction list box
 */

        private bool GetTransaction(string TrxNumber)
        {
            bool TrxExists = false;
// Clear any store transactions if exists

            TransactionListBox.Items.Clear();

            if (File.Exists(FILELOCATION))
            {
// If File Exists
                string Line;
                StreamReader file = new StreamReader(FILELOCATION);
                int LineNumber = 1;
                while ((Line = file.ReadLine()) != null)
                {

/* Check if the transaction numbered entered is at 1st position or not 
* check if the length of transaction is equal to 6 or not 
* and check if the transaction exists or not, if all three condtion 
* add the transaction number to the list
*/
                    if (TrxNumber == Line && Line.Length == TRANSACTIONLENGTH 
                        && (LineNumber % VALUESSTOREDFORONETRX) ==
                        TRANSACTIONNOPOSITION)
                    {
                        TransactionListBox.Items.Add(Line);

                    }
// Increment line Number by 1

                    LineNumber++;
                }
                if (TransactionListBox.Items.Count > 0)
                {
/* If Transaction List box contains some item, unhide appropriate labels
 * to display values
 */
                    SummaryTermLabelBox.Visible = true;
                    SummaryTermValueBox.Visible = true;
                    SummaryBalanceLabelBox.Visible = true;
                    SummaryBalanceValueBox.Visible = true;
                    SummaryInterestRateLabelBox.Visible = true;
                    SummaryInterestRateValueBox.Visible = true;
                    SummaryGroupBox.Visible = true;
// Set Boolean value of TrxExists to True
                    TrxExists = true;


                }
// Close file
                file.Close();
            }
            else
            {
// if file doesn't exist, show  message to commit at least one transaction

                MessageBox.Show("No Transactions Committed Yet, " +
                                "Try Later", "Notification",
                                MessageBoxButtons.OK, 
                                MessageBoxIcon.Warning);

// Focus gets diverted to Display Button Box

                DisplayButtonBox.Focus();
            }
            return TrxExists;
        }

/* A boolean method to displays the summary of a transaction stored in the 
 * transaction list box once selected 
 */
        private void TrxSummaryByTrxNumber(string TrxNumber)
        {
/* Enable, Rename, clear and Unhide all the appropriate label boxes which 
 * shows the relevant information of a transaction
 */
            SummaryTrxNumberLabelBox.Text = "Transaction Number";
            SummaryCustNumLabelBox.Text = "Customer Name";
            SummaryTelNumLabelBox.Text = "Telephone Number";
            SummaryEmailLabelBox.Text = "Email Address";
            SummaryTermLabelBox.Visible = true;
            SummaryTermValueBox.Visible = true;
            SummaryBalanceLabelBox.Visible = true;
            SummaryBalanceValueBox.Visible = true;
            SummaryInterestRateLabelBox.Visible = true;
            SummaryInterestRateValueBox.Visible = true;
            SummaryTrxValueBox.Text = "";
            SummaryCustNameValueBox.Text = "";
            SummaryTelNumValueBox.Text = "";
            SummaryEmailAddValueBox.Text = "";
            SummaryTermValueBox.Text = "";
            SummaryInterestRateValueBox.Text = "";
            SummaryBalanceValueBox.Text = "";

            string Line;
            StreamReader file = new StreamReader(FILELOCATION);
            int rlines = 1;
            int TrxReader = 1;
            bool TrxExists = false;
            while ((Line = file.ReadLine()) != null)
            {
// Loop through the files
                TrxReader = rlines % VALUESSTOREDFORONETRX;
// if condition of length and position satisfies, update trxExists to true

                TrxExists |= (TrxNumber == Line &&
                    (rlines % VALUESSTOREDFORONETRX) == TRANSACTIONNOPOSITION);

                if (TrxExists)
                {
// if TrxExists is equal to true

                    switch (TrxReader)
                    {
                        case 1:
// Check the modulo trxreader, if 1 fill in the Transaction label box
                            SummaryTrxValueBox.Text = Line;
                            break;
                        case 2:
// Check the modulo trxreader, if 2 fill in the Customer name label box
                            SummaryCustNameValueBox.Text = Line;
                            break;
                        case 3:
// Check the modulo trxreader, if 3 fill in the Telephone number label box
                            SummaryTelNumValueBox.Text = Line;
                            break;
                        case 4:
// Check the modulo trxreader, if 4 fill in the Email address label box
                            SummaryEmailAddValueBox.Text = Line;
                            break;
                        case 5:
// Check the modulo trxreader, if 5 fill in the Term label box
                            SummaryTermValueBox.Text = Line;
                            break;
                        case 6:
// Check the modulo trxreader, if 6 fill in the Interest Rate label box
                            SummaryInterestRateValueBox.Text = Line;
                            break;
                        case 7:
// Check the modulo trxreader, if 7 fill in the Balance label box
                            SummaryBalanceValueBox.Text = Line;
                            break;
                        default:
                            TrxExists = false;
                            break;
                    }
                }
// Increment Line Value by 1
                rlines++;
            }
// Close the file
            file.Close();
        }

        private bool GetTrxByEmail(string CustEmailID)
        {

            bool EmailExists = false;
// Clear Transaction List Box;
            TransactionListBox.Items.Clear();

            if (File.Exists(FILELOCATION))
            {
// if file exists at the location

                string Line;
                int LineNumber = 1;
                string trxNum = "";
                string CustomerEmail = "";

// create a file object

                StreamReader file = new StreamReader(FILELOCATION);
                while ((Line = file.ReadLine()) != null)
                {
// Loop through the file
                    int CheckEmail = LineNumber % 8;
// Normalize value between 0 to 8 by using modular division
                    switch (CheckEmail)
                    {

                        case 1:
/* if normalized index or checkemail is 1, store the value as 
 * transaction number in trxNum
 */
                            trxNum = Line;
                            break;
                        case 4:
/* if normalized index or checkemail is 4, store the value as email in 
 * customeremail variable
 */
                            CustomerEmail = Line;
                            break;
                    }
                    if (CustomerEmail == CustEmailID)
// if customeremail value matches with the CustEmailID input parameter
                    {
// Store the value of transaction in transaction list box
                        TransactionListBox.Items.Add(trxNum);
                        CustomerEmail = "";
                    }
// increase line number by 1
                    LineNumber++;

                }
                if (TransactionListBox.Items.Count > 0)
                {
// if there are elements in transaction list box, unhide appropraite labels
                    SummaryTermLabelBox.Visible = true;
                    SummaryTermValueBox.Visible = true;
                    SummaryBalanceLabelBox.Visible = true;
                    SummaryBalanceValueBox.Visible = true;
                    SummaryInterestRateLabelBox.Visible = true;
                    SummaryInterestRateValueBox.Visible = true;
                    SummaryGroupBox.Visible = true;
/* since the transaction list box will be having more than zero value, 
 * change the EmailExists flag to true
 */
                    EmailExists = true;
                }
                file.DiscardBufferedData();
                file.Close();

            }
            else
            {
// if file doesn't exists, pop up a message box to commit transactions

                MessageBox.Show("No Transactions Committed Yet, Try Later",
                                "Notification", MessageBoxButtons.OK, 
                                MessageBoxIcon.Warning);
                DisplayButtonBox.Focus();
            }
            return EmailExists;

        }

    }
}
