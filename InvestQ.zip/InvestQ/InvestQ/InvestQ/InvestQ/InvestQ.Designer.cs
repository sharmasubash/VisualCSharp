﻿namespace InvestQ
{
    partial class InvestQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InvestQ));
            this.InputPrincipalTextBox = new System.Windows.Forms.TextBox();
            this.InputInvestmentLabelBox = new System.Windows.Forms.Label();
            this.ClientNameLabelBox = new System.Windows.Forms.Label();
            this.BalanceDetailsGroupBox = new System.Windows.Forms.GroupBox();
            this.ProceedButtonBox = new System.Windows.Forms.Button();
            this.BalanceListBox = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BalanceValueTextBox = new System.Windows.Forms.Label();
            this.TermSelectionTextBox = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.InvestGroupBox = new System.Windows.Forms.GroupBox();
            this.ConfirmButtonBox = new System.Windows.Forms.Button();
            this.InvestorDetailGroupBox = new System.Windows.Forms.GroupBox();
            this.TransactionValueTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.EmailAddressValueTextBox = new System.Windows.Forms.TextBox();
            this.TelephoneNumberValueTextBox = new System.Windows.Forms.TextBox();
            this.CustomerNameValueTextBox = new System.Windows.Forms.TextBox();
            this.EmailAddressLabelBox = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CustomerNameLabelBox = new System.Windows.Forms.Label();
            this.DisplayButtonBox = new System.Windows.Forms.Button();
            this.SummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.SummaryBalanceValueBox = new System.Windows.Forms.Label();
            this.SummaryInterestRateValueBox = new System.Windows.Forms.Label();
            this.SummaryTermValueBox = new System.Windows.Forms.Label();
            this.SummaryTelNumValueBox = new System.Windows.Forms.Label();
            this.SummaryEmailAddValueBox = new System.Windows.Forms.Label();
            this.SummaryCustNameValueBox = new System.Windows.Forms.Label();
            this.SummaryTrxValueBox = new System.Windows.Forms.Label();
            this.SummaryInterestRateLabelBox = new System.Windows.Forms.Label();
            this.SummaryBalanceLabelBox = new System.Windows.Forms.Label();
            this.SummaryTermLabelBox = new System.Windows.Forms.Label();
            this.SummaryEmailLabelBox = new System.Windows.Forms.Label();
            this.SummaryTelNumLabelBox = new System.Windows.Forms.Label();
            this.SummaryCustNumLabelBox = new System.Windows.Forms.Label();
            this.SummaryTrxNumberLabelBox = new System.Windows.Forms.Label();
            this.TransactionListBox = new System.Windows.Forms.ListBox();
            this.TransactionListLabelBox = new System.Windows.Forms.Label();
            this.SearchLabelBox = new System.Windows.Forms.Label();
            this.TrxRadioButton = new System.Windows.Forms.RadioButton();
            this.EmailRadioButtonBox = new System.Windows.Forms.RadioButton();
            this.EnterTrxNumberTextBox = new System.Windows.Forms.Label();
            this.EnterTransactionDetailBox = new System.Windows.Forms.TextBox();
            this.SearchButtonBox = new System.Windows.Forms.Button();
            this.ExitButtonBox = new System.Windows.Forms.Button();
            this.ClearButtonBox = new System.Windows.Forms.Button();
            this.SummaryButtonBox = new System.Windows.Forms.Button();
            this.ToolTips = new System.Windows.Forms.ToolTip(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BalanceDetailsGroupBox.SuspendLayout();
            this.InvestGroupBox.SuspendLayout();
            this.InvestorDetailGroupBox.SuspendLayout();
            this.SummaryGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // InputPrincipalTextBox
            // 
            this.InputPrincipalTextBox.Location = new System.Drawing.Point(308, 16);
            this.InputPrincipalTextBox.Name = "InputPrincipalTextBox";
            this.InputPrincipalTextBox.Size = new System.Drawing.Size(100, 20);
            this.InputPrincipalTextBox.TabIndex = 7;
            this.ToolTips.SetToolTip(this.InputPrincipalTextBox, "Please Enter Numerical Data");
            // 
            // InputInvestmentLabelBox
            // 
            this.InputInvestmentLabelBox.AutoSize = true;
            this.InputInvestmentLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputInvestmentLabelBox.Location = new System.Drawing.Point(68, 15);
            this.InputInvestmentLabelBox.Name = "InputInvestmentLabelBox";
            this.InputInvestmentLabelBox.Size = new System.Drawing.Size(130, 19);
            this.InputInvestmentLabelBox.TabIndex = 6;
            this.InputInvestmentLabelBox.Text = "Principal Investment";
            // 
            // ClientNameLabelBox
            // 
            this.ClientNameLabelBox.AutoSize = true;
            this.ClientNameLabelBox.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClientNameLabelBox.Location = new System.Drawing.Point(361, 655);
            this.ClientNameLabelBox.Name = "ClientNameLabelBox";
            this.ClientNameLabelBox.Size = new System.Drawing.Size(197, 13);
            this.ClientNameLabelBox.TabIndex = 5;
            this.ClientNameLabelBox.Text = "Product of MyInvestment Bank Corp";
            // 
            // BalanceDetailsGroupBox
            // 
            this.BalanceDetailsGroupBox.Controls.Add(this.ProceedButtonBox);
            this.BalanceDetailsGroupBox.Controls.Add(this.BalanceListBox);
            this.BalanceDetailsGroupBox.Controls.Add(this.label3);
            this.BalanceDetailsGroupBox.Controls.Add(this.label1);
            this.BalanceDetailsGroupBox.Controls.Add(this.BalanceValueTextBox);
            this.BalanceDetailsGroupBox.Controls.Add(this.TermSelectionTextBox);
            this.BalanceDetailsGroupBox.Controls.Add(this.Label2);
            this.BalanceDetailsGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BalanceDetailsGroupBox.Location = new System.Drawing.Point(29, 21);
            this.BalanceDetailsGroupBox.Name = "BalanceDetailsGroupBox";
            this.BalanceDetailsGroupBox.Size = new System.Drawing.Size(309, 186);
            this.BalanceDetailsGroupBox.TabIndex = 8;
            this.BalanceDetailsGroupBox.TabStop = false;
            this.BalanceDetailsGroupBox.Text = "Investment Details";
            // 
            // ProceedButtonBox
            // 
            this.ProceedButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProceedButtonBox.Location = new System.Drawing.Point(195, 153);
            this.ProceedButtonBox.Name = "ProceedButtonBox";
            this.ProceedButtonBox.Size = new System.Drawing.Size(75, 23);
            this.ProceedButtonBox.TabIndex = 10;
            this.ProceedButtonBox.Text = "&Proceed";
            this.ProceedButtonBox.UseVisualStyleBackColor = true;
            this.ProceedButtonBox.Click += new System.EventHandler(this.ProceedButtonBox_Click);
            // 
            // BalanceListBox
            // 
            this.BalanceListBox.FormattingEnabled = true;
            this.BalanceListBox.ItemHeight = 19;
            this.BalanceListBox.Location = new System.Drawing.Point(25, 49);
            this.BalanceListBox.Name = "BalanceListBox";
            this.BalanceListBox.Size = new System.Drawing.Size(245, 80);
            this.BalanceListBox.TabIndex = 16;
            this.BalanceListBox.SelectedIndexChanged += new System.EventHandler(this.BalanceListBox_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(207, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 19);
            this.label3.TabIndex = 15;
            this.label3.Text = "Balance";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(107, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 19);
            this.label1.TabIndex = 14;
            this.label1.Text = "Interest Rate";
            // 
            // BalanceValueTextBox
            // 
            this.BalanceValueTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BalanceValueTextBox.Location = new System.Drawing.Point(125, 197);
            this.BalanceValueTextBox.Name = "BalanceValueTextBox";
            this.BalanceValueTextBox.Size = new System.Drawing.Size(57, 19);
            this.BalanceValueTextBox.TabIndex = 13;
            this.BalanceValueTextBox.Text = "                             ";
            // 
            // TermSelectionTextBox
            // 
            this.TermSelectionTextBox.AutoSize = true;
            this.TermSelectionTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TermSelectionTextBox.Location = new System.Drawing.Point(21, 24);
            this.TermSelectionTextBox.Name = "TermSelectionTextBox";
            this.TermSelectionTextBox.Size = new System.Drawing.Size(77, 19);
            this.TermSelectionTextBox.TabIndex = 7;
            this.TermSelectionTextBox.Text = "Select term";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(19, 25);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(0, 19);
            this.Label2.TabIndex = 5;
            // 
            // InvestGroupBox
            // 
            this.InvestGroupBox.Controls.Add(this.ConfirmButtonBox);
            this.InvestGroupBox.Controls.Add(this.InvestorDetailGroupBox);
            this.InvestGroupBox.Controls.Add(this.BalanceDetailsGroupBox);
            this.InvestGroupBox.Location = new System.Drawing.Point(63, 191);
            this.InvestGroupBox.Name = "InvestGroupBox";
            this.InvestGroupBox.Size = new System.Drawing.Size(345, 414);
            this.InvestGroupBox.TabIndex = 8;
            this.InvestGroupBox.TabStop = false;
            // 
            // ConfirmButtonBox
            // 
            this.ConfirmButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmButtonBox.Location = new System.Drawing.Point(224, 388);
            this.ConfirmButtonBox.Name = "ConfirmButtonBox";
            this.ConfirmButtonBox.Size = new System.Drawing.Size(75, 23);
            this.ConfirmButtonBox.TabIndex = 17;
            this.ConfirmButtonBox.Text = "Confirm";
            this.ConfirmButtonBox.UseVisualStyleBackColor = true;
            this.ConfirmButtonBox.Click += new System.EventHandler(this.ConfirmButtonBox_Click);
            // 
            // InvestorDetailGroupBox
            // 
            this.InvestorDetailGroupBox.Controls.Add(this.TransactionValueTextBox);
            this.InvestorDetailGroupBox.Controls.Add(this.label5);
            this.InvestorDetailGroupBox.Controls.Add(this.EmailAddressValueTextBox);
            this.InvestorDetailGroupBox.Controls.Add(this.TelephoneNumberValueTextBox);
            this.InvestorDetailGroupBox.Controls.Add(this.CustomerNameValueTextBox);
            this.InvestorDetailGroupBox.Controls.Add(this.EmailAddressLabelBox);
            this.InvestorDetailGroupBox.Controls.Add(this.label4);
            this.InvestorDetailGroupBox.Controls.Add(this.CustomerNameLabelBox);
            this.InvestorDetailGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestorDetailGroupBox.Location = new System.Drawing.Point(29, 213);
            this.InvestorDetailGroupBox.Name = "InvestorDetailGroupBox";
            this.InvestorDetailGroupBox.Size = new System.Drawing.Size(309, 169);
            this.InvestorDetailGroupBox.TabIndex = 9;
            this.InvestorDetailGroupBox.TabStop = false;
            this.InvestorDetailGroupBox.Text = "Investor Details";
            // 
            // TransactionValueTextBox
            // 
            this.TransactionValueTextBox.Location = new System.Drawing.Point(170, 26);
            this.TransactionValueTextBox.Name = "TransactionValueTextBox";
            this.TransactionValueTextBox.Size = new System.Drawing.Size(100, 26);
            this.TransactionValueTextBox.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 19);
            this.label5.TabIndex = 22;
            this.label5.Text = "Transaction Number";
            // 
            // EmailAddressValueTextBox
            // 
            this.EmailAddressValueTextBox.Location = new System.Drawing.Point(170, 135);
            this.EmailAddressValueTextBox.Name = "EmailAddressValueTextBox";
            this.EmailAddressValueTextBox.Size = new System.Drawing.Size(100, 26);
            this.EmailAddressValueTextBox.TabIndex = 21;
            // 
            // TelephoneNumberValueTextBox
            // 
            this.TelephoneNumberValueTextBox.Location = new System.Drawing.Point(170, 100);
            this.TelephoneNumberValueTextBox.Name = "TelephoneNumberValueTextBox";
            this.TelephoneNumberValueTextBox.Size = new System.Drawing.Size(100, 26);
            this.TelephoneNumberValueTextBox.TabIndex = 20;
            // 
            // CustomerNameValueTextBox
            // 
            this.CustomerNameValueTextBox.Location = new System.Drawing.Point(170, 61);
            this.CustomerNameValueTextBox.Name = "CustomerNameValueTextBox";
            this.CustomerNameValueTextBox.Size = new System.Drawing.Size(100, 26);
            this.CustomerNameValueTextBox.TabIndex = 9;
            // 
            // EmailAddressLabelBox
            // 
            this.EmailAddressLabelBox.AutoSize = true;
            this.EmailAddressLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailAddressLabelBox.Location = new System.Drawing.Point(19, 138);
            this.EmailAddressLabelBox.Name = "EmailAddressLabelBox";
            this.EmailAddressLabelBox.Size = new System.Drawing.Size(96, 19);
            this.EmailAddressLabelBox.TabIndex = 19;
            this.EmailAddressLabelBox.Text = "Email Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 19);
            this.label4.TabIndex = 18;
            this.label4.Text = "Telephone Number";
            // 
            // CustomerNameLabelBox
            // 
            this.CustomerNameLabelBox.AutoSize = true;
            this.CustomerNameLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerNameLabelBox.Location = new System.Drawing.Point(21, 62);
            this.CustomerNameLabelBox.Name = "CustomerNameLabelBox";
            this.CustomerNameLabelBox.Size = new System.Drawing.Size(109, 19);
            this.CustomerNameLabelBox.TabIndex = 17;
            this.CustomerNameLabelBox.Text = "Customer Name";
            // 
            // DisplayButtonBox
            // 
            this.DisplayButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayButtonBox.Location = new System.Drawing.Point(333, 51);
            this.DisplayButtonBox.Name = "DisplayButtonBox";
            this.DisplayButtonBox.Size = new System.Drawing.Size(75, 23);
            this.DisplayButtonBox.TabIndex = 9;
            this.DisplayButtonBox.Text = "&Display";
            this.ToolTips.SetToolTip(this.DisplayButtonBox, "Click to See Investment Details");
            this.DisplayButtonBox.UseVisualStyleBackColor = true;
            this.DisplayButtonBox.Click += new System.EventHandler(this.DisplayButtonBox_Click);
            // 
            // SummaryGroupBox
            // 
            this.SummaryGroupBox.Controls.Add(this.SummaryBalanceValueBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryInterestRateValueBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTermValueBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTelNumValueBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryEmailAddValueBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryCustNameValueBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTrxValueBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryInterestRateLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryBalanceLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTermLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryEmailLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTelNumLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryCustNumLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTrxNumberLabelBox);
            this.SummaryGroupBox.Controls.Add(this.TransactionListBox);
            this.SummaryGroupBox.Controls.Add(this.TransactionListLabelBox);
            this.SummaryGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryGroupBox.Location = new System.Drawing.Point(470, 200);
            this.SummaryGroupBox.Name = "SummaryGroupBox";
            this.SummaryGroupBox.Size = new System.Drawing.Size(406, 431);
            this.SummaryGroupBox.TabIndex = 10;
            this.SummaryGroupBox.TabStop = false;
            this.SummaryGroupBox.Text = "Transaction Summary";
            // 
            // SummaryBalanceValueBox
            // 
            this.SummaryBalanceValueBox.AutoSize = true;
            this.SummaryBalanceValueBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryBalanceValueBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryBalanceValueBox.Location = new System.Drawing.Point(274, 395);
            this.SummaryBalanceValueBox.Name = "SummaryBalanceValueBox";
            this.SummaryBalanceValueBox.Size = new System.Drawing.Size(2, 21);
            this.SummaryBalanceValueBox.TabIndex = 31;
            // 
            // SummaryInterestRateValueBox
            // 
            this.SummaryInterestRateValueBox.AutoSize = true;
            this.SummaryInterestRateValueBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryInterestRateValueBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryInterestRateValueBox.Location = new System.Drawing.Point(274, 363);
            this.SummaryInterestRateValueBox.Name = "SummaryInterestRateValueBox";
            this.SummaryInterestRateValueBox.Size = new System.Drawing.Size(2, 21);
            this.SummaryInterestRateValueBox.TabIndex = 30;
            // 
            // SummaryTermValueBox
            // 
            this.SummaryTermValueBox.AutoSize = true;
            this.SummaryTermValueBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryTermValueBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTermValueBox.Location = new System.Drawing.Point(274, 333);
            this.SummaryTermValueBox.Name = "SummaryTermValueBox";
            this.SummaryTermValueBox.Size = new System.Drawing.Size(2, 21);
            this.SummaryTermValueBox.TabIndex = 29;
            // 
            // SummaryTelNumValueBox
            // 
            this.SummaryTelNumValueBox.AutoSize = true;
            this.SummaryTelNumValueBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryTelNumValueBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTelNumValueBox.Location = new System.Drawing.Point(274, 254);
            this.SummaryTelNumValueBox.Name = "SummaryTelNumValueBox";
            this.SummaryTelNumValueBox.Size = new System.Drawing.Size(2, 21);
            this.SummaryTelNumValueBox.TabIndex = 28;
            // 
            // SummaryEmailAddValueBox
            // 
            this.SummaryEmailAddValueBox.AutoSize = true;
            this.SummaryEmailAddValueBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryEmailAddValueBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryEmailAddValueBox.Location = new System.Drawing.Point(274, 295);
            this.SummaryEmailAddValueBox.Name = "SummaryEmailAddValueBox";
            this.SummaryEmailAddValueBox.Size = new System.Drawing.Size(2, 21);
            this.SummaryEmailAddValueBox.TabIndex = 27;
            // 
            // SummaryCustNameValueBox
            // 
            this.SummaryCustNameValueBox.AutoSize = true;
            this.SummaryCustNameValueBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryCustNameValueBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryCustNameValueBox.Location = new System.Drawing.Point(274, 214);
            this.SummaryCustNameValueBox.Name = "SummaryCustNameValueBox";
            this.SummaryCustNameValueBox.Size = new System.Drawing.Size(2, 21);
            this.SummaryCustNameValueBox.TabIndex = 26;
            // 
            // SummaryTrxValueBox
            // 
            this.SummaryTrxValueBox.AutoSize = true;
            this.SummaryTrxValueBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryTrxValueBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTrxValueBox.Location = new System.Drawing.Point(274, 172);
            this.SummaryTrxValueBox.Name = "SummaryTrxValueBox";
            this.SummaryTrxValueBox.Size = new System.Drawing.Size(2, 21);
            this.SummaryTrxValueBox.TabIndex = 25;
            // 
            // SummaryInterestRateLabelBox
            // 
            this.SummaryInterestRateLabelBox.AutoSize = true;
            this.SummaryInterestRateLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryInterestRateLabelBox.Location = new System.Drawing.Point(12, 363);
            this.SummaryInterestRateLabelBox.Name = "SummaryInterestRateLabelBox";
            this.SummaryInterestRateLabelBox.Size = new System.Drawing.Size(86, 19);
            this.SummaryInterestRateLabelBox.TabIndex = 24;
            this.SummaryInterestRateLabelBox.Text = "Interest Rate";
            // 
            // SummaryBalanceLabelBox
            // 
            this.SummaryBalanceLabelBox.AutoSize = true;
            this.SummaryBalanceLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryBalanceLabelBox.Location = new System.Drawing.Point(11, 395);
            this.SummaryBalanceLabelBox.Name = "SummaryBalanceLabelBox";
            this.SummaryBalanceLabelBox.Size = new System.Drawing.Size(57, 19);
            this.SummaryBalanceLabelBox.TabIndex = 23;
            this.SummaryBalanceLabelBox.Text = "Balance";
            // 
            // SummaryTermLabelBox
            // 
            this.SummaryTermLabelBox.AutoSize = true;
            this.SummaryTermLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTermLabelBox.Location = new System.Drawing.Point(11, 333);
            this.SummaryTermLabelBox.Name = "SummaryTermLabelBox";
            this.SummaryTermLabelBox.Size = new System.Drawing.Size(40, 19);
            this.SummaryTermLabelBox.TabIndex = 22;
            this.SummaryTermLabelBox.Text = "Term";
            // 
            // SummaryEmailLabelBox
            // 
            this.SummaryEmailLabelBox.AutoSize = true;
            this.SummaryEmailLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryEmailLabelBox.Location = new System.Drawing.Point(12, 295);
            this.SummaryEmailLabelBox.Name = "SummaryEmailLabelBox";
            this.SummaryEmailLabelBox.Size = new System.Drawing.Size(96, 19);
            this.SummaryEmailLabelBox.TabIndex = 21;
            this.SummaryEmailLabelBox.Text = "Email Address";
            // 
            // SummaryTelNumLabelBox
            // 
            this.SummaryTelNumLabelBox.AutoSize = true;
            this.SummaryTelNumLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTelNumLabelBox.Location = new System.Drawing.Point(12, 254);
            this.SummaryTelNumLabelBox.Name = "SummaryTelNumLabelBox";
            this.SummaryTelNumLabelBox.Size = new System.Drawing.Size(125, 19);
            this.SummaryTelNumLabelBox.TabIndex = 20;
            this.SummaryTelNumLabelBox.Text = "Telephone Number";
            // 
            // SummaryCustNumLabelBox
            // 
            this.SummaryCustNumLabelBox.AutoSize = true;
            this.SummaryCustNumLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryCustNumLabelBox.Location = new System.Drawing.Point(11, 214);
            this.SummaryCustNumLabelBox.Name = "SummaryCustNumLabelBox";
            this.SummaryCustNumLabelBox.Size = new System.Drawing.Size(109, 19);
            this.SummaryCustNumLabelBox.TabIndex = 19;
            this.SummaryCustNumLabelBox.Text = "Customer Name";
            // 
            // SummaryTrxNumberLabelBox
            // 
            this.SummaryTrxNumberLabelBox.AutoSize = true;
            this.SummaryTrxNumberLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTrxNumberLabelBox.Location = new System.Drawing.Point(11, 172);
            this.SummaryTrxNumberLabelBox.Name = "SummaryTrxNumberLabelBox";
            this.SummaryTrxNumberLabelBox.Size = new System.Drawing.Size(132, 19);
            this.SummaryTrxNumberLabelBox.TabIndex = 18;
            this.SummaryTrxNumberLabelBox.Text = "Transaction Number";
            // 
            // TransactionListBox
            // 
            this.TransactionListBox.FormattingEnabled = true;
            this.TransactionListBox.ItemHeight = 19;
            this.TransactionListBox.Location = new System.Drawing.Point(15, 67);
            this.TransactionListBox.Name = "TransactionListBox";
            this.TransactionListBox.Size = new System.Drawing.Size(171, 80);
            this.TransactionListBox.TabIndex = 0;
            this.TransactionListBox.SelectedIndexChanged += new System.EventHandler(this.TransactionListBox_SelectedIndexChanged);
            // 
            // TransactionListLabelBox
            // 
            this.TransactionListLabelBox.AutoSize = true;
            this.TransactionListLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionListLabelBox.Location = new System.Drawing.Point(11, 43);
            this.TransactionListLabelBox.Name = "TransactionListLabelBox";
            this.TransactionListLabelBox.Size = new System.Drawing.Size(120, 19);
            this.TransactionListLabelBox.TabIndex = 17;
            this.TransactionListLabelBox.Text = "List of Transaction";
            // 
            // SearchLabelBox
            // 
            this.SearchLabelBox.AutoSize = true;
            this.SearchLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLabelBox.Location = new System.Drawing.Point(466, 17);
            this.SearchLabelBox.Name = "SearchLabelBox";
            this.SearchLabelBox.Size = new System.Drawing.Size(180, 19);
            this.SearchLabelBox.TabIndex = 11;
            this.SearchLabelBox.Text = "Search Previous Transaction";
            // 
            // TrxRadioButton
            // 
            this.TrxRadioButton.AutoSize = true;
            this.TrxRadioButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrxRadioButton.Location = new System.Drawing.Point(656, 17);
            this.TrxRadioButton.Name = "TrxRadioButton";
            this.TrxRadioButton.Size = new System.Drawing.Size(70, 19);
            this.TrxRadioButton.TabIndex = 12;
            this.TrxRadioButton.TabStop = true;
            this.TrxRadioButton.Text = "By Trx #";
            this.TrxRadioButton.UseVisualStyleBackColor = true;
            this.TrxRadioButton.CheckedChanged += new System.EventHandler(this.TrxRadioButton_CheckedChanged);
            // 
            // EmailRadioButtonBox
            // 
            this.EmailRadioButtonBox.AutoSize = true;
            this.EmailRadioButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailRadioButtonBox.Location = new System.Drawing.Point(735, 18);
            this.EmailRadioButtonBox.Name = "EmailRadioButtonBox";
            this.EmailRadioButtonBox.Size = new System.Drawing.Size(87, 19);
            this.EmailRadioButtonBox.TabIndex = 13;
            this.EmailRadioButtonBox.TabStop = true;
            this.EmailRadioButtonBox.Text = "By Email ID";
            this.EmailRadioButtonBox.UseVisualStyleBackColor = true;
            this.EmailRadioButtonBox.CheckedChanged += new System.EventHandler(this.EmailRadioButtonBox_CheckedChanged);
            // 
            // EnterTrxNumberTextBox
            // 
            this.EnterTrxNumberTextBox.AutoSize = true;
            this.EnterTrxNumberTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterTrxNumberTextBox.Location = new System.Drawing.Point(466, 60);
            this.EnterTrxNumberTextBox.Name = "EnterTrxNumberTextBox";
            this.EnterTrxNumberTextBox.Size = new System.Drawing.Size(168, 19);
            this.EnterTrxNumberTextBox.TabIndex = 14;
            this.EnterTrxNumberTextBox.Text = "Enter Transaction Number";
            // 
            // EnterTransactionDetailBox
            // 
            this.EnterTransactionDetailBox.Location = new System.Drawing.Point(662, 59);
            this.EnterTransactionDetailBox.Name = "EnterTransactionDetailBox";
            this.EnterTransactionDetailBox.Size = new System.Drawing.Size(160, 20);
            this.EnterTransactionDetailBox.TabIndex = 15;
            // 
            // SearchButtonBox
            // 
            this.SearchButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButtonBox.Location = new System.Drawing.Point(747, 96);
            this.SearchButtonBox.Name = "SearchButtonBox";
            this.SearchButtonBox.Size = new System.Drawing.Size(75, 23);
            this.SearchButtonBox.TabIndex = 16;
            this.SearchButtonBox.Text = "Search";
            this.SearchButtonBox.UseVisualStyleBackColor = true;
            this.SearchButtonBox.Click += new System.EventHandler(this.SearchButtonBox_Click);
            // 
            // ExitButtonBox
            // 
            this.ExitButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButtonBox.Location = new System.Drawing.Point(72, 148);
            this.ExitButtonBox.Name = "ExitButtonBox";
            this.ExitButtonBox.Size = new System.Drawing.Size(75, 23);
            this.ExitButtonBox.TabIndex = 17;
            this.ExitButtonBox.Text = "&Exit";
            this.ToolTips.SetToolTip(this.ExitButtonBox, "Click to Exit Application");
            this.ExitButtonBox.UseVisualStyleBackColor = true;
            this.ExitButtonBox.Click += new System.EventHandler(this.ExitButtonBox_Click);
            // 
            // ClearButtonBox
            // 
            this.ClearButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButtonBox.Location = new System.Drawing.Point(409, 148);
            this.ClearButtonBox.Name = "ClearButtonBox";
            this.ClearButtonBox.Size = new System.Drawing.Size(75, 23);
            this.ClearButtonBox.TabIndex = 18;
            this.ClearButtonBox.Text = "&Clear";
            this.ClearButtonBox.UseVisualStyleBackColor = true;
            this.ClearButtonBox.Click += new System.EventHandler(this.ClearButtonBox_Click);
            // 
            // SummaryButtonBox
            // 
            this.SummaryButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryButtonBox.Location = new System.Drawing.Point(746, 148);
            this.SummaryButtonBox.Name = "SummaryButtonBox";
            this.SummaryButtonBox.Size = new System.Drawing.Size(75, 23);
            this.SummaryButtonBox.TabIndex = 19;
            this.SummaryButtonBox.Text = "&Summary";
            this.ToolTips.SetToolTip(this.SummaryButtonBox, "Displays all the transactions");
            this.SummaryButtonBox.UseVisualStyleBackColor = true;
            this.SummaryButtonBox.Click += new System.EventHandler(this.SummaryButtonBox_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::InvestQ.Properties.Resources.InvestQLogo;
            this.pictureBox1.Location = new System.Drawing.Point(256, 624);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // InvestQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 687);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.SummaryButtonBox);
            this.Controls.Add(this.ClearButtonBox);
            this.Controls.Add(this.ExitButtonBox);
            this.Controls.Add(this.SearchButtonBox);
            this.Controls.Add(this.EnterTransactionDetailBox);
            this.Controls.Add(this.EnterTrxNumberTextBox);
            this.Controls.Add(this.EmailRadioButtonBox);
            this.Controls.Add(this.TrxRadioButton);
            this.Controls.Add(this.SearchLabelBox);
            this.Controls.Add(this.InvestGroupBox);
            this.Controls.Add(this.SummaryGroupBox);
            this.Controls.Add(this.DisplayButtonBox);
            this.Controls.Add(this.InputPrincipalTextBox);
            this.Controls.Add(this.InputInvestmentLabelBox);
            this.Controls.Add(this.ClientNameLabelBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InvestQ";
            this.Text = "InvestQ";
            this.Load += new System.EventHandler(this.InvestQ_Load);
            this.BalanceDetailsGroupBox.ResumeLayout(false);
            this.BalanceDetailsGroupBox.PerformLayout();
            this.InvestGroupBox.ResumeLayout(false);
            this.InvestorDetailGroupBox.ResumeLayout(false);
            this.InvestorDetailGroupBox.PerformLayout();
            this.SummaryGroupBox.ResumeLayout(false);
            this.SummaryGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox InputPrincipalTextBox;
        internal System.Windows.Forms.Label InputInvestmentLabelBox;
        internal System.Windows.Forms.Label ClientNameLabelBox;
        internal System.Windows.Forms.GroupBox BalanceDetailsGroupBox;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label BalanceValueTextBox;
        internal System.Windows.Forms.Label TermSelectionTextBox;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.GroupBox InvestGroupBox;
        private System.Windows.Forms.GroupBox InvestorDetailGroupBox;
        private System.Windows.Forms.ListBox BalanceListBox;
        internal System.Windows.Forms.TextBox EmailAddressValueTextBox;
        internal System.Windows.Forms.TextBox TelephoneNumberValueTextBox;
        internal System.Windows.Forms.TextBox CustomerNameValueTextBox;
        internal System.Windows.Forms.Label EmailAddressLabelBox;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.Label CustomerNameLabelBox;
        private System.Windows.Forms.Button DisplayButtonBox;
        private System.Windows.Forms.Button ProceedButtonBox;
        internal System.Windows.Forms.TextBox TransactionValueTextBox;
        internal System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button ConfirmButtonBox;
        private System.Windows.Forms.GroupBox SummaryGroupBox;
        private System.Windows.Forms.ListBox TransactionListBox;
        internal System.Windows.Forms.Label TransactionListLabelBox;
        internal System.Windows.Forms.Label SummaryCustNumLabelBox;
        internal System.Windows.Forms.Label SummaryTrxNumberLabelBox;
        internal System.Windows.Forms.Label SummaryTelNumLabelBox;
        internal System.Windows.Forms.Label SearchLabelBox;
        private System.Windows.Forms.RadioButton TrxRadioButton;
        private System.Windows.Forms.RadioButton EmailRadioButtonBox;
        internal System.Windows.Forms.Label EnterTrxNumberTextBox;
        internal System.Windows.Forms.TextBox EnterTransactionDetailBox;
        private System.Windows.Forms.Button SearchButtonBox;
        internal System.Windows.Forms.Label SummaryBalanceLabelBox;
        internal System.Windows.Forms.Label SummaryTermLabelBox;
        internal System.Windows.Forms.Label SummaryEmailLabelBox;
        internal System.Windows.Forms.Label SummaryInterestRateLabelBox;
        internal System.Windows.Forms.Label SummaryBalanceValueBox;
        internal System.Windows.Forms.Label SummaryInterestRateValueBox;
        internal System.Windows.Forms.Label SummaryTermValueBox;
        internal System.Windows.Forms.Label SummaryTelNumValueBox;
        internal System.Windows.Forms.Label SummaryEmailAddValueBox;
        internal System.Windows.Forms.Label SummaryCustNameValueBox;
        internal System.Windows.Forms.Label SummaryTrxValueBox;
        private System.Windows.Forms.Button ExitButtonBox;
        private System.Windows.Forms.Button ClearButtonBox;
        private System.Windows.Forms.Button SummaryButtonBox;
        private System.Windows.Forms.ToolTip ToolTips;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

