﻿/*
**************************************************************
| Student Name: Subash Sharma                                |
| Student ID: 18231592                                       |
| Date: 30/10/2018                                           |
| Assignment 03: An Application which enable Sales team of   |
|                Learn2Prog.Ltd to process Bookings for the  |
|                Workshops conducted across various Locations|
|                in Ireland.                                 |
**************************************************************
 */



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


// The Directory or Namespace where the source code will get stored

namespace Learn2ProgLtd
{
/* A form class which handles the functionality of the created
 * Application
 */
    public partial class Learn2Prog : Form
    {

/* Global variables which holds the values of Registration fees, Meal Price,
 * Certificate Cost, No of Days and Lodging fees
 */
        int LoginCount = 3;
        decimal RegistrationFee=0.00M;
        decimal MealPrice=0.00M;
        decimal PrintedCertificatePrice=0.00M;
        decimal LodgingFeesPerDay=0.00M;
        int NoOfDays=0;

/* Global variable which holds the value of the aggregates such as Total 
 * Bookings Registration Fees, Food Cost, Printing Cost, Lodging Cost and Total 
 * Training Cost
 */
        int TotalBookings = 0;
        decimal TotalRegistrationFee = 0.00M;
        decimal TotalLodgingFee = 0.00M;
        decimal TotalFoodCost = 0.00M;
        decimal TotalPrintingCost = 0.00M;
        decimal TotalAdditionalCost = 0.00M;
        decimal TotalTrainingCost = 0.00M;

 // An Empty Constructor to Initialize the Form Class: Learn2Prog

        public Learn2Prog()
        {
            InitializeComponent();
        }

/* On Application Load,Shows only Login Group Box and Related Labels, All other
 * group boxes, Labels, Combo Box etc. remains disabled
 */

        private void Learn2Prog_Load(object sender, EventArgs e)
        {
            InstructionGroupBox.Visible = false;
            ProgramEventGroupBox.Visible = false;
            EnterUserNameTextBox.Focus();
            LogInButton.Select();
            SummaryFoodTextLabelBox.Visible = false;
            SummaryFoodValueLabelBox.Visible = false;
            SummaryPrintedCertificateTextLabelBox.Visible = false;
            SummaryPrintedCertificateValueLabelBox.Visible = false;
            SummaryDailyFoodCostTextLabelBox.Visible = false;
            SummaryDailyFoodCostValueLabelBox.Visible = false;

        }

// On Click Login Button Method (Login Page)

        private void LogInButton_Click(object sender, EventArgs e)
        {
            if (EnterPasswordTextBox.Text == "iLoveVisualC#")
            {

/* If entered Password is correct, Enable Instructions Group Box and Disable 
 * rest other group Boxes
 */
                LoginGroupBox.Visible = false;
                LoginPictureBox.Visible = false;
                InstructionGroupBox.Visible = true;
                ProgramEventGroupBox.Visible = false;

/* Captures the Text User Name Input to Show the Name of User on Instruction 
 * Page
 */
                DisplayUserNameLabelBox.Text = EnterUserNameTextBox.Text+"!";
                }
            else
                {

/* With each Wrong User Entry of Password, Decrease the limit of Login Attempts
 * by one. Maximum Limit is 3.
 */
                LoginCount = LoginCount-1;

                if (LoginCount==0)
                {

//if all the 3 login attempts exhausted, Close the Application

                    MessageBox.Show("Attempts Exhausted, Closing Application");
                    this.Close();

                }

// Displays the login attempts left by subtracting 1 from the login Max Limit
                
                MessageBox.Show("Please Enter Correct Password, Attempts Left "
                                + LoginCount.ToString(),"Error",
                                MessageBoxButtons.OK,MessageBoxIcon.Error);
                EnterPasswordTextBox.Focus();
                EnterPasswordTextBox.SelectAll();
                }
        }

// On Click Ok Button Method (Instructions Page)

        private void OkButtonBox_Click(object sender, EventArgs e)
        {
            if (YesRadioButton.Checked)
            {

/* If user presses Radio Button "Yes" , he is allowed to 
 * view Summary Page
 */
                OkButtonBox.Focus();
                InstructionGroupBox.Visible = false;
                ProgramEventGroupBox.Visible = true;
                MealPlanDropDownLabelBox.Visible = false;
                MealPlanComboBox.Visible = false;
                BookButton.Enabled = false;
                ProgramListBox.Focus();
                LocationListBox.Focus();
                DisplayButtonBox.Focus();
            }
            else
            {

/* Application get closed in rest other cases, such as pressing "No" Radio 
 *               Button
 */
                this.Close();
            }
        }

/* When User checks Radio Button of Meal Box as "yes", he/she is allowed to 
 * view the Food Menu and to choose a food meal plan
 */

        private void MealBoxYesRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            MealPlanDropDownLabelBox.Visible = true;
            MealPlanComboBox.Visible = true;
        }

/* If user check No radio Button, he/she is not allowed to view the Meal Menu 
 * Plan
 */
        private void MealBoxNoRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            MealPlanComboBox.Visible = false;
            MealPlanDropDownLabelBox.Visible = false;

/* Even Summary Group Box which contains the meal value or total price get 
 * disabled
 */
            SummaryFoodTextLabelBox.Visible = false;
            SummaryFoodValueLabelBox.Visible = false;
            SummaryDailyFoodCostTextLabelBox.Visible = false;
            SummaryDailyFoodCostValueLabelBox.Visible = false;
        }
 
// On Click Display Button Method(Summary Page)

        private void DisplayButtonBox_Click(object sender, EventArgs e)
        {

/* Whenever User Presses Display Button, it resets the Global Variable values
 * to zero, These Global Variables acts a Local variable in this method
 */
            RegistrationFee = 0.00M;
            MealPrice = 0.00M;
            PrintedCertificatePrice = 0.00M;
            LodgingFeesPerDay = 0.00M;
            NoOfDays = 0;

// Selection of a Program and Location is Mandatory

            if (ProgramListBox.SelectedIndex != -1 && 
                LocationListBox.SelectedIndex != -1)
            {

/* If user selects a Program and a location, Set Variables such as No of Days,
 * Registration Fee and Lodging Fees Per Day as per the selection
 */ 
                switch (ProgramListBox.SelectedIndex)
                {
// When the Selected Program is "ASP.NET with C#"
                    case 0:
                        RegistrationFee = 1200.00M;
                        NoOfDays = 4;
                        break;
// When the Selected program is "Winfrom App with C#"
                    case 1:
                        RegistrationFee = 1000.00M;
                        NoOfDays = 3;
                        break;
// When the Selected Program is ".Net Prog using C# Part 1"
                    case 2:
                        RegistrationFee = 1500.00M;
                        NoOfDays = 4;
                        break;
// When the Selected Program is ".Net Prog using C# par 2"
                    case 3:
                        RegistrationFee = 1800.00M;
                        NoOfDays = 4;
                        break;
// When the Selected Program is "Digital Detox"
                    case 4:
                        RegistrationFee = 599.00M;
                        NoOfDays = 1;
                        break;
// Default makes cost and days as zero
                    default:
                        RegistrationFee = 0;
                        NoOfDays = 0;    
                        break;
                }
                switch (LocationListBox.SelectedIndex)
                {
// When the Selected Location is Cork
                    case 0:
                        LodgingFeesPerDay = 150.00M;
                        break;
// When the Selected Location is Dublin
                    case 1:
                        LodgingFeesPerDay = 225.00M;
                        break;
// When the Selected Location is Galway
                    case 2:
                        LodgingFeesPerDay = 175.00M;
                        break;
// When the Selected Location is Belmullet
                    case 3:
                        LodgingFeesPerDay = 305.00M;
                        break;
// When the Selected Location is Limerick
                    case 4:
                        LodgingFeesPerDay = 135.00M;
                        break;
// When the Selected Location is Wexford
                    case 5:
                        LodgingFeesPerDay = 89.00M;
                        break;
// By Default, LOdging Fees per day is Zero
                    default:
                        LodgingFeesPerDay = 0.00M; 
                        break;
                }

                if (MealBoxYesRadioButton.Checked)
                {

 /* If user selects the Meal Box Radio Button as yes, Change Visibility of  
  * Meal Plan related Label and Combo Box to True
  */
                    SummaryFoodTextLabelBox.Visible = true;
                    SummaryFoodValueLabelBox.Visible = true;
                    SummaryDailyFoodCostTextLabelBox.Visible = true;
                    SummaryDailyFoodCostValueLabelBox.Visible = true;

                    if (MealPlanComboBox.SelectedIndex != -1)
                    {
/* If user opts for a meal Plan, Set variable such as Meal Price as per the 
 * selection
 */
                        switch (MealPlanComboBox.SelectedItem)
                        {
// When User selects "Full Board"
                            case "Full Board":
                                MealPrice = 39.50M;
                                break;
// When User Selects "Half Board"
                            case "Half Board":
                                MealPrice = 27.50M;
                                break;
// When User Selects "Only Breakfast"
                            case "Only Breakfast":
                                MealPrice = 12.50M;
                                break;
// By Default, Make Meal Price as Zero
                            default:
                                MealPrice = 0.00M;
                                break;
                        }
                    }
                }
// If user chooses No radio Button, Set the Meal Price to Zero
                
                if (MealBoxNoRadioButton.Checked)
                {
                    MealPrice = 0.00M;
                }

                
                if (PrintedCertificateYesCheckBox.Checked)
                {

 // if User opt for a printed Certificate, Set Cost of Certification to €29.95 

                    SummaryPrintedCertificateTextLabelBox.Visible = true;
                    SummaryPrintedCertificateValueLabelBox.Visible = true;
                    PrintedCertificatePrice = 29.95M;
                }

// Else Set the Printed Certificate Cost to Zero

                else PrintedCertificatePrice = 0.00M;

/* As the Display and Summary Button Uses Summary Group Box Attributes, 
 * We will rename the relevant label boxes to display the meaningful operation
 * everytime the Display button is clicked
 */
                SummaryTrainingDayTextLabelBox.Text = "# of Training Days";
                SummaryRegFeeTextLabelBox.Text = "Registration Fee";
                SummaryLodgingTextBox.Text = "Lodging Fee";
                SummaryLodgingPerDayTextLabelBox.Text = "Lodging Fee per Day";
                SummaryTotalTrainingTextlabelBox.Text = "Total Training Cost";

 /* Display the value of Lodging fees per day as per the location
 * selection
 */
                
                SummaryLodgingPerDayValueLabelBox.Text = LodgingFeesPerDay.
                    ToString("€#.##");

/* Calculate total Meal Price as per the program duration and display 
 */
                SummaryFoodValueLabelBox.Text = (MealPrice * NoOfDays).
                    ToString("€#.##");

// Display the Daily Meal Price

                SummaryDailyFoodCostValueLabelBox.Text = MealPrice.
                    ToString("€#.##");

// Display the Certificate Cost 

                SummaryPrintedCertificateValueLabelBox.Text = 
                    PrintedCertificatePrice.ToString("€#.##");

// Displays the Number of Days are per the Program Selection

                SummaryTrainingValueTextBox.Text = 
                    NoOfDays.ToString() + " Days";

// Displays the registration Fees as per the Program Selection

                SummaryRegFeeValueLabelBox.Text = 
                    RegistrationFee.ToString("€#.##");

 // Displays the Total Lodging Fees = Product (Lodging Fees per Day * No of Days)

                SummaryLodgingFeeValueLabelBox.Text = 
                    (LodgingFeesPerDay * NoOfDays).ToString("€#.##");

/* Displays the Total Training Cost = product (Meal Price,
 * No of days)  + product (Lodging Fees per Day, No of Days) + Registration Fees
 * and Printed Certificate Price
 */


                SummaryTotalTrainingCostValueLabelBox.Text = 
                    ((MealPrice * NoOfDays) +
                     (LodgingFeesPerDay * NoOfDays) +
                     RegistrationFee+PrintedCertificatePrice).ToString("€#.##");

/* Once All these Values are calcuated, Enable Summary Group Box and Book 
 * Button and shift focus to Book Button
 */
                SummaryGroupBox.Visible = true;
                BookButton.Enabled = true;
                BookButton.Focus();
            }
            else
            {

/* If a Program and a Location is not selected, Display a Warning Message 
 * to User to choose a Program and a Location and shift the focus to Program
 * and Location List Box
 */
                MessageBox.Show("Please select a Program and a Location",
                                "Warning",MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                ProgramListBox.Focus();
                LocationListBox.Focus();

            }
        }

// On Click Summary Button Method (Summary Page)

        private void SummaryButton_Click(object sender, EventArgs e)
        {
        
            if (TotalBookings == 0)
            {

/* If user hasn't booked any Workshop Event, Display all summary aggregated
 * values to zero
 */

                SummaryTotalTrainingCostValueLabelBox.Text = "€0.00";
                SummaryRegFeeValueLabelBox.Text = "€0.00";
                SummaryLodgingFeeValueLabelBox.Text = "€0.00";
                SummaryLodgingPerDayValueLabelBox.Text = "€0.00";
                SummaryTrainingValueTextBox.Text = "0.00";
            }
            else
            {

/* if user has booked workshop event, Calculate and Display Average Revenue 
 * per Booking = Total Cost of Training / Total Number of Bookings, Divide by 
 * zero Error Handled Above
 */
                SummaryTotalTrainingCostValueLabelBox.Text = 
                    (TotalTrainingCost / TotalBookings).ToString("€#.##");

// Display Total Number of Bookings of all Booked Events

                SummaryTrainingValueTextBox.Text = TotalBookings.ToString();

// Display Total Registration fees of all booked Events

                SummaryRegFeeValueLabelBox.Text = TotalRegistrationFee
                    .ToString("€#.##");

// Display Total Lodging Fees of all Booked Events

                SummaryLodgingFeeValueLabelBox.Text = TotalLodgingFee
                    .ToString("€#.##");
                if (TotalAdditionalCost==0)

// if the Total Additional Cost is Zero, Display the value of chosen Option 0

                    SummaryLodgingPerDayValueLabelBox.Text = "€0.00";
                else

// If the Total Additional Cost is not Zero, display the aggreated Value

                    SummaryLodgingPerDayValueLabelBox.Text = TotalAdditionalCost
                        .ToString("€#.##");

/* Display Total Number of Bookings, Please note that the calculations of 
 * aggregated values occurs in Book Button
 */

                SummaryTrainingValueTextBox.Text = TotalBookings.ToString();
            }

/* On Click of Summary Button Change the Label names to appropriate text,
 * while showing the aggregates of Booked Summary
 */

            SummaryTrainingDayTextLabelBox.Text = "Total # of Bookings";
            SummaryRegFeeTextLabelBox.Text = "Total Registration Fees";
            SummaryLodgingTextBox.Text = "Total Lodging Fees";
            SummaryLodgingPerDayTextLabelBox.Text = "Total Additional Cost";
            SummaryTotalTrainingTextlabelBox.Text = "Average Revenue per Booking";

/* On click of Summary Button, Hide all irrelevant label boxes such as Printed 
 * certificate cost (Text, Value) Food Cost (Text, Value), Disable Book Button 
 * and Shift focus to Clear Button
 */

            SummaryPrintedCertificateTextLabelBox.Visible = false;
            SummaryPrintedCertificateValueLabelBox.Visible = false;
            SummaryFoodTextLabelBox.Visible = false;
            SummaryFoodValueLabelBox.Visible = false;
            SummaryDailyFoodCostTextLabelBox.Visible = false;
            SummaryDailyFoodCostValueLabelBox.Visible = false;
            BookButton.Enabled = false;
            ClearButton.Focus();
        }

 // On Click Book Button Method (Summary Page)

        private void BookButton_Click(object sender, EventArgs e)
        {

/* When User Presses Book Button, Confimration Message gets Displayed to 
 * the user with Yes and No Button
 */

            DialogResult confirm = MessageBox.Show("Would you like to make" +
                                                   " the Booking, Please" +
                                                   " confirm by clicking on" +
                                                   " Yes ?", "Confirmation", 
                                                   MessageBoxButtons.YesNo,
                                                   MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)

/* if User Presses yes Button or Confirms the Booking, 
 */
            {
/* As the List Box of Program and location contains information about no of Days
 * ,registration fees and Lodging, we split the string of the values and fetch
 * only the first value of the list
 */
                string[] location = LocationListBox.SelectedItem.ToString()
                                                   .Split('\t');
                string[] program = ProgramListBox.SelectedItem.ToString()
                                                 .Split('\t');

 /* A new Message will be Displayed to the user about Booking Confirmation
  * Success Message with necessary information and asking user if he/she would 
  * want to make another booking
 */
                DialogResult Result = MessageBox.Show("You have successfully" +
                                                      " Booked your Seat for " +
                                                      "the upcoming " +
                                                      program[0]
                    + " Workshop Event going to be in " + location[0] +
                                                      " Location.The total " +
                                                      "amount of Booking is " +
                                                      ((MealPrice * NoOfDays) +
                                               (LodgingFeesPerDay * NoOfDays) +
                                                             RegistrationFee + 
                                                       PrintedCertificatePrice)
                                                      .ToString("€#.##") + 
                                                 " , Would you like to make " +
                    "another booking ?  ", "Congratulations!"
                    , MessageBoxButtons.YesNo, MessageBoxIcon.Information);

// Increment Value by 1, if an event is booked

                TotalBookings++;

/* Add Current Registration fees to the Total Registration Fee to display 
 * new Total Registration Fee Value
 */

                TotalRegistrationFee = RegistrationFee + TotalRegistrationFee;

/* New Total Lodging Fees = 
 * Current (Lodging Fees per Day * No of Days) + Existing Total Lodging Fees
 */

                TotalLodgingFee = (LodgingFeesPerDay * NoOfDays) + 
                    TotalLodgingFee;

/* New Total Food Cost = Current (Meal Price * No of Days ) + 
 * Existing Total Food Cost
 */

                TotalFoodCost = (MealPrice * NoOfDays) + TotalFoodCost;

/* New Total Printing Cost = Current Printed Certificate Price
 * + Existing Total Printing Cost
 */
                TotalPrintingCost = PrintedCertificatePrice + TotalPrintingCost;

/* New Total Additional Cost = Existing Total Additional Cost + Current
 * Total Food Cost + Existing Total Printing Cost
 */
                TotalAdditionalCost = TotalAdditionalCost + 
                    TotalFoodCost + TotalPrintingCost;

/* New Total Training Cost = Current ( Meal Price * No of Days) + current 
 * (Lodging Fees per Day * No of Days) + Current Registration Fees + Current
 * Printed Certificate Price + Existing Total Training Cost
 */

                TotalTrainingCost = ((MealPrice * NoOfDays) +
                                     (LodgingFeesPerDay * NoOfDays) +
                                    RegistrationFee + PrintedCertificatePrice)
                    + TotalTrainingCost;

/* Disable Book Button to avoid rebooking by mistake, Please note that 
 * Booking button only gets enabled once pressed on Display Button
 */

                BookButton.Enabled = false;

/* Shift the Focus on Clear Button on last, so that user can clear 
 * the existing selection and goes for another booking 
 */

                ClearButton.Focus();
            }
        }

/* On Click Clear Button Method (Summary Page), this button will reset the
 * form to the initial stage
 */

        private void ClearButton_Click(object sender, EventArgs e)
        {

// Enable Display button, if its disabled by any means

            DisplayButtonBox.Enabled = true;

// clear selection of Location and Program List Box

            LocationListBox.ClearSelected();
            ProgramListBox.ClearSelected();

// Uncheck Meal Radio Button

            MealBoxNoRadioButton.Checked = false;
            MealBoxYesRadioButton.Checked = false;

// Hide Meal Drop Down Combo label 

            MealPlanDropDownLabelBox.Visible = false;

// Clear selection of Meal, if in case any selected

            MealPlanComboBox.SelectedIndex = -1;

// Hide Meal Plan Combo Drop Down Box

            MealPlanComboBox.Visible = false;

/* Book button gets enabled only when user View the cost of his selection by 
 * clicking on display button
 */

            BookButton.Enabled = false;

// Hide Value and Text label of Food Cost

            SummaryFoodTextLabelBox.Visible = false;
            SummaryFoodValueLabelBox.Visible = false;

// Hide Value and text label of Daily Food Cost

            SummaryDailyFoodCostTextLabelBox.Visible = false;
            SummaryDailyFoodCostValueLabelBox.Visible = false;

// Hide Value and Text label of Printed Certificate cost

            SummaryPrintedCertificateTextLabelBox.Visible = false;
            SummaryPrintedCertificateValueLabelBox.Visible = false;

// Uncheck the checked box of Printed Certificate 

            PrintedCertificateYesCheckBox.Checked = false;

/* As the Form goes to Initial Stage of Summary Page, We make sure to rename 
 * the labels so that the display button shows the correct information
 */
            SummaryTrainingDayTextLabelBox.Text = "# of Training Days";
            SummaryRegFeeTextLabelBox.Text = "Registration Fee";
            SummaryLodgingTextBox.Text = "Lodging Fee";
            SummaryLodgingPerDayTextLabelBox.Text = "Lodging Fee per Day";
            SummaryTotalTrainingTextlabelBox.Text = "Total Training Cost";

// Clear values in the Value labels

            SummaryFoodValueLabelBox.Text = "";
            SummaryLodgingFeeValueLabelBox.Text = "";
            SummaryLodgingPerDayValueLabelBox.Text = "";
            SummaryPrintedCertificateValueLabelBox.Text = "";
            SummaryRegFeeValueLabelBox.Text = "";
            SummaryTotalTrainingCostValueLabelBox.Text = "";
            SummaryTrainingValueTextBox.Text = "";

        }


/* If user unchecks the printed summary certificate Label box, 
 * it hides and changes the resets the value of Printed certificate price
 * 
 */

        private void PrintedCertificateYesCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            SummaryPrintedCertificateTextLabelBox.Visible = false;
            SummaryPrintedCertificateValueLabelBox.Visible = false;
            PrintedCertificatePrice = 0.00M;
        }
// On Click Exit Button to Close the Application

        private void ExitButtonBox_Click(object sender, EventArgs e)
        {
            this.Close();

        }

    }
}
