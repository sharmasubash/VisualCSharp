﻿namespace Learn2ProgLtd
{
    partial class Learn2Prog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Learn2Prog));
            this.ProgramListBox = new System.Windows.Forms.ListBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.LoginGroupBox = new System.Windows.Forms.GroupBox();
            this.LogInButton = new System.Windows.Forms.Button();
            this.EnterPasswordTextBox = new System.Windows.Forms.TextBox();
            this.EnterUserNameTextBox = new System.Windows.Forms.TextBox();
            this.UserNameLabelBox = new System.Windows.Forms.Label();
            this.PasswordlabelBox = new System.Windows.Forms.Label();
            this.LoginPictureBox = new System.Windows.Forms.PictureBox();
            this.InstructionGroupBox = new System.Windows.Forms.GroupBox();
            this.OkButtonBox = new System.Windows.Forms.Button();
            this.NoRadioButton = new System.Windows.Forms.RadioButton();
            this.YesRadioButton = new System.Windows.Forms.RadioButton();
            this.ProceedMessageLabelBox = new System.Windows.Forms.Label();
            this.InstructionLabel1Box = new System.Windows.Forms.Label();
            this.InstructionHeaderLabelBox = new System.Windows.Forms.Label();
            this.ProgramEventGroupBox = new System.Windows.Forms.GroupBox();
            this.PrintedCertificateYesCheckBox = new System.Windows.Forms.CheckBox();
            this.SummaryButton = new System.Windows.Forms.Button();
            this.ExitButtonBox = new System.Windows.Forms.Button();
            this.DisplayButtonBox = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.SummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.SummaryDailyFoodCostValueLabelBox = new System.Windows.Forms.Label();
            this.BookButton = new System.Windows.Forms.Button();
            this.SummaryDailyFoodCostTextLabelBox = new System.Windows.Forms.Label();
            this.SummaryLodgingPerDayValueLabelBox = new System.Windows.Forms.Label();
            this.SummaryLodgingPerDayTextLabelBox = new System.Windows.Forms.Label();
            this.SummaryTotalTrainingCostValueLabelBox = new System.Windows.Forms.Label();
            this.SummaryTotalTrainingTextlabelBox = new System.Windows.Forms.Label();
            this.SummaryPrintedCertificateValueLabelBox = new System.Windows.Forms.Label();
            this.SummaryFoodValueLabelBox = new System.Windows.Forms.Label();
            this.SummaryLodgingFeeValueLabelBox = new System.Windows.Forms.Label();
            this.SummaryRegFeeValueLabelBox = new System.Windows.Forms.Label();
            this.SummaryTrainingValueTextBox = new System.Windows.Forms.Label();
            this.SummaryPrintedCertificateTextLabelBox = new System.Windows.Forms.Label();
            this.SummaryFoodTextLabelBox = new System.Windows.Forms.Label();
            this.SummaryLodgingTextBox = new System.Windows.Forms.Label();
            this.SummaryRegFeeTextLabelBox = new System.Windows.Forms.Label();
            this.SummaryTrainingDayTextLabelBox = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.MealPlanComboBox = new System.Windows.Forms.ComboBox();
            this.MealPlanDropDownLabelBox = new System.Windows.Forms.Label();
            this.MealBoxNoRadioButton = new System.Windows.Forms.RadioButton();
            this.MealBoxYesRadioButton = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LocationListBox = new System.Windows.Forms.ListBox();
            this.WelcomeLabelBox = new System.Windows.Forms.Label();
            this.DisplayUserNameLabelBox = new System.Windows.Forms.Label();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.LoginGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LoginPictureBox)).BeginInit();
            this.InstructionGroupBox.SuspendLayout();
            this.ProgramEventGroupBox.SuspendLayout();
            this.SummaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // ProgramListBox
            // 
            this.ProgramListBox.AllowDrop = true;
            this.ProgramListBox.BackColor = System.Drawing.SystemColors.Info;
            this.ProgramListBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProgramListBox.FormattingEnabled = true;
            this.ProgramListBox.ItemHeight = 19;
            this.ProgramListBox.Items.AddRange(new object[] {
            "ASP.NET with C#\t\t4 Days\t€1200",
            "Winform Apps With C#\t3 Days\t€1000",
            ".NET Prog using C# Part 1\t4 Days\t€1500",
            ".NET Prog using C# Part 2\t4 Days\t€1800",
            "Digital Detox\t\t1 Day\t€599"});
            this.ProgramListBox.Location = new System.Drawing.Point(121, 52);
            this.ProgramListBox.Name = "ProgramListBox";
            this.ProgramListBox.Size = new System.Drawing.Size(337, 118);
            this.ProgramListBox.TabIndex = 5;
            this.toolTip.SetToolTip(this.ProgramListBox, "Program and Location are Mandatory");
            // 
            // LoginGroupBox
            // 
            this.LoginGroupBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LoginGroupBox.Controls.Add(this.LogInButton);
            this.LoginGroupBox.Controls.Add(this.EnterPasswordTextBox);
            this.LoginGroupBox.Controls.Add(this.EnterUserNameTextBox);
            this.LoginGroupBox.Controls.Add(this.UserNameLabelBox);
            this.LoginGroupBox.Controls.Add(this.PasswordlabelBox);
            this.LoginGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LoginGroupBox.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginGroupBox.Location = new System.Drawing.Point(352, 223);
            this.LoginGroupBox.Name = "LoginGroupBox";
            this.LoginGroupBox.Size = new System.Drawing.Size(283, 148);
            this.LoginGroupBox.TabIndex = 13;
            this.LoginGroupBox.TabStop = false;
            this.LoginGroupBox.Text = "Sign In";
            // 
            // LogInButton
            // 
            this.LogInButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.LogInButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogInButton.Location = new System.Drawing.Point(153, 106);
            this.LogInButton.Name = "LogInButton";
            this.LogInButton.Size = new System.Drawing.Size(72, 23);
            this.LogInButton.TabIndex = 4;
            this.LogInButton.Text = "Log In";
            this.LogInButton.UseVisualStyleBackColor = true;
            this.LogInButton.Click += new System.EventHandler(this.LogInButton_Click);
            // 
            // EnterPasswordTextBox
            // 
            this.EnterPasswordTextBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterPasswordTextBox.Location = new System.Drawing.Point(125, 66);
            this.EnterPasswordTextBox.Name = "EnterPasswordTextBox";
            this.EnterPasswordTextBox.PasswordChar = '*';
            this.EnterPasswordTextBox.Size = new System.Drawing.Size(100, 22);
            this.EnterPasswordTextBox.TabIndex = 3;
            // 
            // EnterUserNameTextBox
            // 
            this.EnterUserNameTextBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterUserNameTextBox.Location = new System.Drawing.Point(125, 35);
            this.EnterUserNameTextBox.Name = "EnterUserNameTextBox";
            this.EnterUserNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.EnterUserNameTextBox.TabIndex = 2;
            // 
            // UserNameLabelBox
            // 
            this.UserNameLabelBox.AutoSize = true;
            this.UserNameLabelBox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UserNameLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserNameLabelBox.Location = new System.Drawing.Point(22, 35);
            this.UserNameLabelBox.Name = "UserNameLabelBox";
            this.UserNameLabelBox.Size = new System.Drawing.Size(79, 19);
            this.UserNameLabelBox.TabIndex = 0;
            this.UserNameLabelBox.Text = "User Name";
            // 
            // PasswordlabelBox
            // 
            this.PasswordlabelBox.AutoSize = true;
            this.PasswordlabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordlabelBox.Location = new System.Drawing.Point(32, 66);
            this.PasswordlabelBox.Name = "PasswordlabelBox";
            this.PasswordlabelBox.Size = new System.Drawing.Size(69, 19);
            this.PasswordlabelBox.TabIndex = 1;
            this.PasswordlabelBox.Text = "Password";
            // 
            // LoginPictureBox
            // 
            this.LoginPictureBox.Image = global::Learn2ProgLtd.Properties.Resources.loginKey;
            this.LoginPictureBox.Location = new System.Drawing.Point(193, 223);
            this.LoginPictureBox.Name = "LoginPictureBox";
            this.LoginPictureBox.Size = new System.Drawing.Size(159, 148);
            this.LoginPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LoginPictureBox.TabIndex = 5;
            this.LoginPictureBox.TabStop = false;
            // 
            // InstructionGroupBox
            // 
            this.InstructionGroupBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.InstructionGroupBox.Controls.Add(this.DisplayUserNameLabelBox);
            this.InstructionGroupBox.Controls.Add(this.WelcomeLabelBox);
            this.InstructionGroupBox.Controls.Add(this.OkButtonBox);
            this.InstructionGroupBox.Controls.Add(this.NoRadioButton);
            this.InstructionGroupBox.Controls.Add(this.YesRadioButton);
            this.InstructionGroupBox.Controls.Add(this.ProceedMessageLabelBox);
            this.InstructionGroupBox.Controls.Add(this.InstructionLabel1Box);
            this.InstructionGroupBox.Controls.Add(this.InstructionHeaderLabelBox);
            this.InstructionGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructionGroupBox.Location = new System.Drawing.Point(94, 194);
            this.InstructionGroupBox.Name = "InstructionGroupBox";
            this.InstructionGroupBox.Size = new System.Drawing.Size(551, 375);
            this.InstructionGroupBox.TabIndex = 5;
            this.InstructionGroupBox.TabStop = false;
            this.InstructionGroupBox.Text = "Instructions";
            // 
            // OkButtonBox
            // 
            this.OkButtonBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.OkButtonBox.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OkButtonBox.Location = new System.Drawing.Point(430, 332);
            this.OkButtonBox.Name = "OkButtonBox";
            this.OkButtonBox.Size = new System.Drawing.Size(72, 23);
            this.OkButtonBox.TabIndex = 5;
            this.OkButtonBox.Text = "Ok";
            this.OkButtonBox.UseVisualStyleBackColor = true;
            this.OkButtonBox.Click += new System.EventHandler(this.OkButtonBox_Click);
            // 
            // NoRadioButton
            // 
            this.NoRadioButton.AutoSize = true;
            this.NoRadioButton.Location = new System.Drawing.Point(455, 286);
            this.NoRadioButton.Name = "NoRadioButton";
            this.NoRadioButton.Size = new System.Drawing.Size(47, 23);
            this.NoRadioButton.TabIndex = 4;
            this.NoRadioButton.TabStop = true;
            this.NoRadioButton.Text = "No";
            this.NoRadioButton.UseVisualStyleBackColor = true;
            // 
            // YesRadioButton
            // 
            this.YesRadioButton.AutoSize = true;
            this.YesRadioButton.Location = new System.Drawing.Point(351, 288);
            this.YesRadioButton.Name = "YesRadioButton";
            this.YesRadioButton.Size = new System.Drawing.Size(50, 23);
            this.YesRadioButton.TabIndex = 3;
            this.YesRadioButton.TabStop = true;
            this.YesRadioButton.Text = "Yes";
            this.YesRadioButton.UseVisualStyleBackColor = true;
            // 
            // ProceedMessageLabelBox
            // 
            this.ProceedMessageLabelBox.AutoSize = true;
            this.ProceedMessageLabelBox.Location = new System.Drawing.Point(23, 290);
            this.ProceedMessageLabelBox.Name = "ProceedMessageLabelBox";
            this.ProceedMessageLabelBox.Size = new System.Drawing.Size(185, 19);
            this.ProceedMessageLabelBox.TabIndex = 2;
            this.ProceedMessageLabelBox.Text = "Do you want to Continue ?";
            // 
            // InstructionLabel1Box
            // 
            this.InstructionLabel1Box.AutoSize = true;
            this.InstructionLabel1Box.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstructionLabel1Box.Location = new System.Drawing.Point(21, 80);
            this.InstructionLabel1Box.Name = "InstructionLabel1Box";
            this.InstructionLabel1Box.Size = new System.Drawing.Size(511, 180);
            this.InstructionLabel1Box.TabIndex = 1;
            this.InstructionLabel1Box.Text = resources.GetString("InstructionLabel1Box.Text");
            // 
            // InstructionHeaderLabelBox
            // 
            this.InstructionHeaderLabelBox.AutoSize = true;
            this.InstructionHeaderLabelBox.Location = new System.Drawing.Point(21, 42);
            this.InstructionHeaderLabelBox.Name = "InstructionHeaderLabelBox";
            this.InstructionHeaderLabelBox.Size = new System.Drawing.Size(456, 19);
            this.InstructionHeaderLabelBox.TabIndex = 0;
            this.InstructionHeaderLabelBox.Text = "Before Clicking on Yes Button, Please read the instruction carefully";
            // 
            // ProgramEventGroupBox
            // 
            this.ProgramEventGroupBox.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ProgramEventGroupBox.Controls.Add(this.PrintedCertificateYesCheckBox);
            this.ProgramEventGroupBox.Controls.Add(this.SummaryButton);
            this.ProgramEventGroupBox.Controls.Add(this.ExitButtonBox);
            this.ProgramEventGroupBox.Controls.Add(this.DisplayButtonBox);
            this.ProgramEventGroupBox.Controls.Add(this.ClearButton);
            this.ProgramEventGroupBox.Controls.Add(this.SummaryGroupBox);
            this.ProgramEventGroupBox.Controls.Add(this.label4);
            this.ProgramEventGroupBox.Controls.Add(this.MealPlanComboBox);
            this.ProgramEventGroupBox.Controls.Add(this.MealPlanDropDownLabelBox);
            this.ProgramEventGroupBox.Controls.Add(this.MealBoxNoRadioButton);
            this.ProgramEventGroupBox.Controls.Add(this.MealBoxYesRadioButton);
            this.ProgramEventGroupBox.Controls.Add(this.label3);
            this.ProgramEventGroupBox.Controls.Add(this.label2);
            this.ProgramEventGroupBox.Controls.Add(this.label1);
            this.ProgramEventGroupBox.Controls.Add(this.LocationListBox);
            this.ProgramEventGroupBox.Controls.Add(this.ProgramListBox);
            this.ProgramEventGroupBox.Location = new System.Drawing.Point(101, 28);
            this.ProgramEventGroupBox.Name = "ProgramEventGroupBox";
            this.ProgramEventGroupBox.Size = new System.Drawing.Size(788, 652);
            this.ProgramEventGroupBox.TabIndex = 14;
            this.ProgramEventGroupBox.TabStop = false;
            // 
            // PrintedCertificateYesCheckBox
            // 
            this.PrintedCertificateYesCheckBox.AutoSize = true;
            this.PrintedCertificateYesCheckBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintedCertificateYesCheckBox.Location = new System.Drawing.Point(515, 261);
            this.PrintedCertificateYesCheckBox.Name = "PrintedCertificateYesCheckBox";
            this.PrintedCertificateYesCheckBox.Size = new System.Drawing.Size(50, 23);
            this.PrintedCertificateYesCheckBox.TabIndex = 24;
            this.PrintedCertificateYesCheckBox.Text = "Yes";
            this.PrintedCertificateYesCheckBox.UseVisualStyleBackColor = true;
            this.PrintedCertificateYesCheckBox.CheckedChanged += new System.EventHandler(this.PrintedCertificateYesCheckBox_CheckedChanged);
            // 
            // SummaryButton
            // 
            this.SummaryButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.SummaryButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SummaryButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryButton.Location = new System.Drawing.Point(123, 303);
            this.SummaryButton.Name = "SummaryButton";
            this.SummaryButton.Size = new System.Drawing.Size(72, 23);
            this.SummaryButton.TabIndex = 22;
            this.SummaryButton.Text = "Summary";
            this.toolTip.SetToolTip(this.SummaryButton, "Shows the Booking Summary");
            this.SummaryButton.UseVisualStyleBackColor = false;
            this.SummaryButton.Click += new System.EventHandler(this.SummaryButton_Click);
            // 
            // ExitButtonBox
            // 
            this.ExitButtonBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ExitButtonBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ExitButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButtonBox.Location = new System.Drawing.Point(600, 584);
            this.ExitButtonBox.Name = "ExitButtonBox";
            this.ExitButtonBox.Size = new System.Drawing.Size(72, 23);
            this.ExitButtonBox.TabIndex = 20;
            this.ExitButtonBox.Text = "Exit";
            this.toolTip.SetToolTip(this.ExitButtonBox, "To Exit, Press This Button");
            this.ExitButtonBox.UseVisualStyleBackColor = false;
            this.ExitButtonBox.Click += new System.EventHandler(this.ExitButtonBox_Click);
            // 
            // DisplayButtonBox
            // 
            this.DisplayButtonBox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.DisplayButtonBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.DisplayButtonBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayButtonBox.Location = new System.Drawing.Point(599, 301);
            this.DisplayButtonBox.Name = "DisplayButtonBox";
            this.DisplayButtonBox.Size = new System.Drawing.Size(72, 23);
            this.DisplayButtonBox.TabIndex = 19;
            this.DisplayButtonBox.Text = "Display";
            this.DisplayButtonBox.UseVisualStyleBackColor = false;
            this.DisplayButtonBox.Click += new System.EventHandler(this.DisplayButtonBox_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ClearButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.Location = new System.Drawing.Point(361, 303);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(72, 23);
            this.ClearButton.TabIndex = 21;
            this.ClearButton.Text = "Clear";
            this.toolTip.SetToolTip(this.ClearButton, "Click on Clear to Reset Form");
            this.ClearButton.UseVisualStyleBackColor = false;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // SummaryGroupBox
            // 
            this.SummaryGroupBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.SummaryGroupBox.Controls.Add(this.SummaryDailyFoodCostValueLabelBox);
            this.SummaryGroupBox.Controls.Add(this.BookButton);
            this.SummaryGroupBox.Controls.Add(this.SummaryDailyFoodCostTextLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryLodgingPerDayValueLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryLodgingPerDayTextLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTotalTrainingCostValueLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTotalTrainingTextlabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryPrintedCertificateValueLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryFoodValueLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryLodgingFeeValueLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryRegFeeValueLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTrainingValueTextBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryPrintedCertificateTextLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryFoodTextLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryLodgingTextBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryRegFeeTextLabelBox);
            this.SummaryGroupBox.Controls.Add(this.SummaryTrainingDayTextLabelBox);
            this.SummaryGroupBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryGroupBox.Location = new System.Drawing.Point(123, 338);
            this.SummaryGroupBox.Name = "SummaryGroupBox";
            this.SummaryGroupBox.Size = new System.Drawing.Size(548, 240);
            this.SummaryGroupBox.TabIndex = 18;
            this.SummaryGroupBox.TabStop = false;
            // 
            // SummaryDailyFoodCostValueLabelBox
            // 
            this.SummaryDailyFoodCostValueLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryDailyFoodCostValueLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryDailyFoodCostValueLabelBox.Location = new System.Drawing.Point(455, 118);
            this.SummaryDailyFoodCostValueLabelBox.Name = "SummaryDailyFoodCostValueLabelBox";
            this.SummaryDailyFoodCostValueLabelBox.Size = new System.Drawing.Size(67, 21);
            this.SummaryDailyFoodCostValueLabelBox.TabIndex = 38;
            // 
            // BookButton
            // 
            this.BookButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BookButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.BookButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BookButton.Location = new System.Drawing.Point(450, 211);
            this.BookButton.Name = "BookButton";
            this.BookButton.Size = new System.Drawing.Size(72, 23);
            this.BookButton.TabIndex = 23;
            this.BookButton.Text = "Book";
            this.BookButton.UseVisualStyleBackColor = false;
            this.BookButton.Click += new System.EventHandler(this.BookButton_Click);
            // 
            // SummaryDailyFoodCostTextLabelBox
            // 
            this.SummaryDailyFoodCostTextLabelBox.AutoSize = true;
            this.SummaryDailyFoodCostTextLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryDailyFoodCostTextLabelBox.Location = new System.Drawing.Point(240, 119);
            this.SummaryDailyFoodCostTextLabelBox.Name = "SummaryDailyFoodCostTextLabelBox";
            this.SummaryDailyFoodCostTextLabelBox.Size = new System.Drawing.Size(115, 19);
            this.SummaryDailyFoodCostTextLabelBox.TabIndex = 37;
            this.SummaryDailyFoodCostTextLabelBox.Text = "Daily Food Cost";
            // 
            // SummaryLodgingPerDayValueLabelBox
            // 
            this.SummaryLodgingPerDayValueLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryLodgingPerDayValueLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryLodgingPerDayValueLabelBox.Location = new System.Drawing.Point(455, 30);
            this.SummaryLodgingPerDayValueLabelBox.Name = "SummaryLodgingPerDayValueLabelBox";
            this.SummaryLodgingPerDayValueLabelBox.Size = new System.Drawing.Size(67, 19);
            this.SummaryLodgingPerDayValueLabelBox.TabIndex = 34;
            // 
            // SummaryLodgingPerDayTextLabelBox
            // 
            this.SummaryLodgingPerDayTextLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryLodgingPerDayTextLabelBox.Location = new System.Drawing.Point(240, 32);
            this.SummaryLodgingPerDayTextLabelBox.Name = "SummaryLodgingPerDayTextLabelBox";
            this.SummaryLodgingPerDayTextLabelBox.Size = new System.Drawing.Size(151, 19);
            this.SummaryLodgingPerDayTextLabelBox.TabIndex = 33;
            this.SummaryLodgingPerDayTextLabelBox.Text = "Lodging Fees per Day";
            // 
            // SummaryTotalTrainingCostValueLabelBox
            // 
            this.SummaryTotalTrainingCostValueLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryTotalTrainingCostValueLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTotalTrainingCostValueLabelBox.Location = new System.Drawing.Point(455, 182);
            this.SummaryTotalTrainingCostValueLabelBox.Name = "SummaryTotalTrainingCostValueLabelBox";
            this.SummaryTotalTrainingCostValueLabelBox.Size = new System.Drawing.Size(67, 21);
            this.SummaryTotalTrainingCostValueLabelBox.TabIndex = 32;
            // 
            // SummaryTotalTrainingTextlabelBox
            // 
            this.SummaryTotalTrainingTextlabelBox.AutoSize = true;
            this.SummaryTotalTrainingTextlabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTotalTrainingTextlabelBox.Location = new System.Drawing.Point(238, 182);
            this.SummaryTotalTrainingTextlabelBox.Name = "SummaryTotalTrainingTextlabelBox";
            this.SummaryTotalTrainingTextlabelBox.Size = new System.Drawing.Size(141, 19);
            this.SummaryTotalTrainingTextlabelBox.TabIndex = 31;
            this.SummaryTotalTrainingTextlabelBox.Text = "Total Training Cost";
            // 
            // SummaryPrintedCertificateValueLabelBox
            // 
            this.SummaryPrintedCertificateValueLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryPrintedCertificateValueLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryPrintedCertificateValueLabelBox.Location = new System.Drawing.Point(455, 149);
            this.SummaryPrintedCertificateValueLabelBox.Name = "SummaryPrintedCertificateValueLabelBox";
            this.SummaryPrintedCertificateValueLabelBox.Size = new System.Drawing.Size(67, 21);
            this.SummaryPrintedCertificateValueLabelBox.TabIndex = 30;
            // 
            // SummaryFoodValueLabelBox
            // 
            this.SummaryFoodValueLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryFoodValueLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryFoodValueLabelBox.Location = new System.Drawing.Point(169, 119);
            this.SummaryFoodValueLabelBox.Name = "SummaryFoodValueLabelBox";
            this.SummaryFoodValueLabelBox.Size = new System.Drawing.Size(60, 21);
            this.SummaryFoodValueLabelBox.TabIndex = 29;
            // 
            // SummaryLodgingFeeValueLabelBox
            // 
            this.SummaryLodgingFeeValueLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryLodgingFeeValueLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryLodgingFeeValueLabelBox.Location = new System.Drawing.Point(455, 58);
            this.SummaryLodgingFeeValueLabelBox.Name = "SummaryLodgingFeeValueLabelBox";
            this.SummaryLodgingFeeValueLabelBox.Size = new System.Drawing.Size(67, 21);
            this.SummaryLodgingFeeValueLabelBox.TabIndex = 28;
            // 
            // SummaryRegFeeValueLabelBox
            // 
            this.SummaryRegFeeValueLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryRegFeeValueLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryRegFeeValueLabelBox.Location = new System.Drawing.Point(169, 59);
            this.SummaryRegFeeValueLabelBox.Name = "SummaryRegFeeValueLabelBox";
            this.SummaryRegFeeValueLabelBox.Size = new System.Drawing.Size(60, 21);
            this.SummaryRegFeeValueLabelBox.TabIndex = 27;
            // 
            // SummaryTrainingValueTextBox
            // 
            this.SummaryTrainingValueTextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.SummaryTrainingValueTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTrainingValueTextBox.Location = new System.Drawing.Point(169, 32);
            this.SummaryTrainingValueTextBox.Name = "SummaryTrainingValueTextBox";
            this.SummaryTrainingValueTextBox.Size = new System.Drawing.Size(60, 19);
            this.SummaryTrainingValueTextBox.TabIndex = 26;
            // 
            // SummaryPrintedCertificateTextLabelBox
            // 
            this.SummaryPrintedCertificateTextLabelBox.AutoSize = true;
            this.SummaryPrintedCertificateTextLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryPrintedCertificateTextLabelBox.Location = new System.Drawing.Point(241, 151);
            this.SummaryPrintedCertificateTextLabelBox.Name = "SummaryPrintedCertificateTextLabelBox";
            this.SummaryPrintedCertificateTextLabelBox.Size = new System.Drawing.Size(164, 19);
            this.SummaryPrintedCertificateTextLabelBox.TabIndex = 25;
            this.SummaryPrintedCertificateTextLabelBox.Text = "Printed Certificate Cost";
            // 
            // SummaryFoodTextLabelBox
            // 
            this.SummaryFoodTextLabelBox.AutoSize = true;
            this.SummaryFoodTextLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryFoodTextLabelBox.Location = new System.Drawing.Point(10, 119);
            this.SummaryFoodTextLabelBox.Name = "SummaryFoodTextLabelBox";
            this.SummaryFoodTextLabelBox.Size = new System.Drawing.Size(114, 19);
            this.SummaryFoodTextLabelBox.TabIndex = 24;
            this.SummaryFoodTextLabelBox.Text = "Total Food Cost";
            // 
            // SummaryLodgingTextBox
            // 
            this.SummaryLodgingTextBox.AutoSize = true;
            this.SummaryLodgingTextBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryLodgingTextBox.Location = new System.Drawing.Point(240, 60);
            this.SummaryLodgingTextBox.Name = "SummaryLodgingTextBox";
            this.SummaryLodgingTextBox.Size = new System.Drawing.Size(140, 19);
            this.SummaryLodgingTextBox.TabIndex = 23;
            this.SummaryLodgingTextBox.Text = "Lodging Fees           ";
            // 
            // SummaryRegFeeTextLabelBox
            // 
            this.SummaryRegFeeTextLabelBox.AutoSize = true;
            this.SummaryRegFeeTextLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryRegFeeTextLabelBox.Location = new System.Drawing.Point(9, 61);
            this.SummaryRegFeeTextLabelBox.Name = "SummaryRegFeeTextLabelBox";
            this.SummaryRegFeeTextLabelBox.Size = new System.Drawing.Size(115, 19);
            this.SummaryRegFeeTextLabelBox.TabIndex = 22;
            this.SummaryRegFeeTextLabelBox.Text = "Registration Fee";
            // 
            // SummaryTrainingDayTextLabelBox
            // 
            this.SummaryTrainingDayTextLabelBox.AutoSize = true;
            this.SummaryTrainingDayTextLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTrainingDayTextLabelBox.Location = new System.Drawing.Point(9, 30);
            this.SummaryTrainingDayTextLabelBox.Name = "SummaryTrainingDayTextLabelBox";
            this.SummaryTrainingDayTextLabelBox.Size = new System.Drawing.Size(128, 19);
            this.SummaryTrainingDayTextLabelBox.TabIndex = 21;
            this.SummaryTrainingDayTextLabelBox.Text = "# of Training Days";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(119, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(304, 38);
            this.label4.TabIndex = 15;
            this.label4.Text = "Would you like to receive a printed Certificate\r\nof Completion ?\r\n";
            // 
            // MealPlanComboBox
            // 
            this.MealPlanComboBox.BackColor = System.Drawing.SystemColors.MenuBar;
            this.MealPlanComboBox.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MealPlanComboBox.FormattingEnabled = true;
            this.MealPlanComboBox.Items.AddRange(new object[] {
            "Full Board",
            "Half Board",
            "Only Breakfast"});
            this.MealPlanComboBox.Location = new System.Drawing.Point(550, 214);
            this.MealPlanComboBox.Name = "MealPlanComboBox";
            this.MealPlanComboBox.Size = new System.Drawing.Size(121, 23);
            this.MealPlanComboBox.TabIndex = 14;
            // 
            // MealPlanDropDownLabelBox
            // 
            this.MealPlanDropDownLabelBox.AutoSize = true;
            this.MealPlanDropDownLabelBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MealPlanDropDownLabelBox.Location = new System.Drawing.Point(232, 218);
            this.MealPlanDropDownLabelBox.Name = "MealPlanDropDownLabelBox";
            this.MealPlanDropDownLabelBox.Size = new System.Drawing.Size(160, 19);
            this.MealPlanDropDownLabelBox.TabIndex = 13;
            this.MealPlanDropDownLabelBox.Text = "Choose your Meal Plan";
            // 
            // MealBoxNoRadioButton
            // 
            this.MealBoxNoRadioButton.AutoSize = true;
            this.MealBoxNoRadioButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MealBoxNoRadioButton.Location = new System.Drawing.Point(614, 185);
            this.MealBoxNoRadioButton.Name = "MealBoxNoRadioButton";
            this.MealBoxNoRadioButton.Size = new System.Drawing.Size(47, 23);
            this.MealBoxNoRadioButton.TabIndex = 12;
            this.MealBoxNoRadioButton.TabStop = true;
            this.MealBoxNoRadioButton.Text = "No";
            this.MealBoxNoRadioButton.UseVisualStyleBackColor = true;
            this.MealBoxNoRadioButton.CheckedChanged += new System.EventHandler(this.MealBoxNoRadioButton_CheckedChanged);
            // 
            // MealBoxYesRadioButton
            // 
            this.MealBoxYesRadioButton.AutoSize = true;
            this.MealBoxYesRadioButton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MealBoxYesRadioButton.Location = new System.Drawing.Point(515, 185);
            this.MealBoxYesRadioButton.Name = "MealBoxYesRadioButton";
            this.MealBoxYesRadioButton.Size = new System.Drawing.Size(49, 23);
            this.MealBoxYesRadioButton.TabIndex = 11;
            this.MealBoxYesRadioButton.TabStop = true;
            this.MealBoxYesRadioButton.Text = "Yes";
            this.toolTip.SetToolTip(this.MealBoxYesRadioButton, "Click on Yes to view the Menu");
            this.MealBoxYesRadioButton.UseVisualStyleBackColor = true;
            this.MealBoxYesRadioButton.CheckedChanged += new System.EventHandler(this.MealBoxYesRadioButton_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(119, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(273, 19);
            this.label3.TabIndex = 10;
            this.label3.Text = "Would you like to opt for our meal plan ?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(480, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 27);
            this.label2.TabIndex = 9;
            this.label2.Text = "Select a Location";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(118, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 27);
            this.label1.TabIndex = 8;
            this.label1.Text = "Select a Program";
            // 
            // LocationListBox
            // 
            this.LocationListBox.AllowDrop = true;
            this.LocationListBox.BackColor = System.Drawing.SystemColors.Info;
            this.LocationListBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LocationListBox.FormattingEnabled = true;
            this.LocationListBox.ItemHeight = 19;
            this.LocationListBox.Items.AddRange(new object[] {
            "Cork\t\t€150",
            "Dublin\t\t€225",
            "Galway\t\t€175",
            "Belmullet\t\t€305",
            "Limerick\t\t€135",
            "Wexford\t\t€89"});
            this.LocationListBox.Location = new System.Drawing.Point(485, 52);
            this.LocationListBox.Name = "LocationListBox";
            this.LocationListBox.Size = new System.Drawing.Size(187, 118);
            this.LocationListBox.TabIndex = 7;
            // 
            // WelcomeLabelBox
            // 
            this.WelcomeLabelBox.AutoSize = true;
            this.WelcomeLabelBox.Location = new System.Drawing.Point(173, 10);
            this.WelcomeLabelBox.Name = "WelcomeLabelBox";
            this.WelcomeLabelBox.Size = new System.Drawing.Size(74, 19);
            this.WelcomeLabelBox.TabIndex = 6;
            this.WelcomeLabelBox.Text = "Welcome,";
            // 
            // DisplayUserNameLabelBox
            // 
            this.DisplayUserNameLabelBox.AutoSize = true;
            this.DisplayUserNameLabelBox.Location = new System.Drawing.Point(242, 10);
            this.DisplayUserNameLabelBox.Name = "DisplayUserNameLabelBox";
            this.DisplayUserNameLabelBox.Size = new System.Drawing.Size(61, 19);
            this.DisplayUserNameLabelBox.TabIndex = 7;
            this.DisplayUserNameLabelBox.Text = "             ";
            // 
            // Learn2Prog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1027, 704);
            this.Controls.Add(this.ProgramEventGroupBox);
            this.Controls.Add(this.LoginPictureBox);
            this.Controls.Add(this.LoginGroupBox);
            this.Controls.Add(this.InstructionGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Learn2Prog";
            this.Text = "Learn2Prog";
            this.Load += new System.EventHandler(this.Learn2Prog_Load);
            this.LoginGroupBox.ResumeLayout(false);
            this.LoginGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LoginPictureBox)).EndInit();
            this.InstructionGroupBox.ResumeLayout(false);
            this.InstructionGroupBox.PerformLayout();
            this.ProgramEventGroupBox.ResumeLayout(false);
            this.ProgramEventGroupBox.PerformLayout();
            this.SummaryGroupBox.ResumeLayout(false);
            this.SummaryGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label UserNameLabelBox;
        private System.Windows.Forms.Label PasswordlabelBox;
        private System.Windows.Forms.TextBox EnterUserNameTextBox;
        private System.Windows.Forms.TextBox EnterPasswordTextBox;
        private System.Windows.Forms.Button LogInButton;
        private System.Windows.Forms.ListBox ProgramListBox;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox LoginGroupBox;
        private System.Windows.Forms.PictureBox LoginPictureBox;
        private System.Windows.Forms.GroupBox InstructionGroupBox;
        private System.Windows.Forms.Label InstructionHeaderLabelBox;
        private System.Windows.Forms.Label InstructionLabel1Box;
        private System.Windows.Forms.Label ProceedMessageLabelBox;
        private System.Windows.Forms.RadioButton NoRadioButton;
        private System.Windows.Forms.RadioButton YesRadioButton;
        private System.Windows.Forms.Button OkButtonBox;
        private System.Windows.Forms.GroupBox ProgramEventGroupBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox LocationListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton MealBoxNoRadioButton;
        private System.Windows.Forms.RadioButton MealBoxYesRadioButton;
        private System.Windows.Forms.Label MealPlanDropDownLabelBox;
        private System.Windows.Forms.ComboBox MealPlanComboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox SummaryGroupBox;
        private System.Windows.Forms.Button DisplayButtonBox;
        private System.Windows.Forms.Button ExitButtonBox;
        private System.Windows.Forms.Label SummaryTrainingDayTextLabelBox;
        private System.Windows.Forms.Label SummaryLodgingTextBox;
        private System.Windows.Forms.Label SummaryRegFeeTextLabelBox;
        private System.Windows.Forms.Label SummaryPrintedCertificateTextLabelBox;
        private System.Windows.Forms.Label SummaryFoodTextLabelBox;
        private System.Windows.Forms.Label SummaryLodgingFeeValueLabelBox;
        private System.Windows.Forms.Label SummaryRegFeeValueLabelBox;
        private System.Windows.Forms.Label SummaryTrainingValueTextBox;
        private System.Windows.Forms.Label SummaryPrintedCertificateValueLabelBox;
        private System.Windows.Forms.Label SummaryFoodValueLabelBox;
        private System.Windows.Forms.Label SummaryTotalTrainingTextlabelBox;
        private System.Windows.Forms.Label SummaryTotalTrainingCostValueLabelBox;
        private System.Windows.Forms.Button SummaryButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button BookButton;
        private System.Windows.Forms.CheckBox PrintedCertificateYesCheckBox;
        private System.Windows.Forms.Label SummaryLodgingPerDayValueLabelBox;
        private System.Windows.Forms.Label SummaryLodgingPerDayTextLabelBox;
        private System.Windows.Forms.Label SummaryDailyFoodCostValueLabelBox;
        private System.Windows.Forms.Label SummaryDailyFoodCostTextLabelBox;
        private System.Windows.Forms.Label DisplayUserNameLabelBox;
        private System.Windows.Forms.Label WelcomeLabelBox;
        private System.Windows.Forms.ToolTip toolTip;
    }
}

